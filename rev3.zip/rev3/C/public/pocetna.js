import Pozivi from './pozivi.js'

function kreirajPrikazSlika(slikeNiz, trenutnaStranica){
    let column = document.getElementById('slike')
    column.innerHTML='';
    for(var i = (trenutnaStranica - 1) * 3; i < (trenutnaStranica - 1) * 3 + 3; i++)
    {   if(slikeNiz[i] == undefined) break;
        let div =  document.createElement('div')
        div.className='column'
        let img  = document.createElement('img');
        img.setAttribute('src', slikeNiz[i]);
        img.setAttribute('alt','slika');

        div.appendChild(img);
        column.appendChild(div);
    }   
  
}


function dohvatiSlike(trenutnaStranica){

    let sljedeci = document.querySelector("#sljedeci")
    Pozivi.dajSlike(function(rez){
        kreirajPrikazSlika(rez.slike, trenutnaStranica)

    if(trenutnaStranica === rez.brojStranica){
        sljedeci.disabled=true;
    }
    else{
        sljedeci.disabled=false
    }
    },trenutnaStranica);

}


function getStats() {
    var xhttp = new XMLHttpRequest();
    xhttp.onreadystatechange = function() {
        if (this.readyState == 4 && this.status == 200) {
            let rezultat = JSON.parse(this.responseText); // dobijam rezultat sa servera
            var ispis = document.getElementById('ispis');
            ispis.innerHTML = "Broj posjetilaca sa Chrome-a: " + rezultat.chrome + 
                               "<br>Broj posjetilaca sa Firefox-a: " + rezultat.firefox + 
                               "<br>Broj razlicitih IP-adresa: " + rezultat.ip_addresses_count;
        }
    };

    xhttp.open('GET', 'http://localhost:8080/stats', true);
    xhttp.send();
}

window.onload = function(){
    getStats();

    let trenutnaStranica = 1
    let prethodni = document.getElementById("prethodni")
    prethodni.disabled = true;
    let sljedeci = document.querySelector("#sljedeci")
    dohvatiSlike(trenutnaStranica)

    prethodni.addEventListener('click',function(event){
        trenutnaStranica--;
        dohvatiSlike(trenutnaStranica)
        if(trenutnaStranica===1){
            prethodni.disabled=true;
        }
      
    })

    sljedeci.addEventListener('click',function(event){
            trenutnaStranica++;
            if(trenutnaStranica!==1){
                prethodni.disabled=false;
            }
            dohvatiSlike(trenutnaStranica)    
    })
}