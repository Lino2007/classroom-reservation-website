import Pozivi from './pozivi.js';

let Kalendar = (function() {
	let periodicna = [];
	let vanredna = [];

	function obojiZauzeca(kalendarRef, mjesec, sala, pocetak, kraj) {
		//ucitani podaci
		let trazeniSemestar = null;
		if ((mjesec >= 9 && mjesec <= 11) || mjesec == 0) {
			trazeniSemestar = 'zimski';
		} else if (mjesec >= 1 && mjesec <= 5) {
			trazeniSemestar = 'ljetni';
		}
		let dan = moment(new Date(2019, mjesec, 1));
		while (dan.month() == mjesec) {
			//oslobodi sve dane u mjesecu
			let indeksDana = dan.date() - 1;
			kalendarRef.children[indeksDana].children[1].classList.remove('zauzeta');
			dan.add(1, 'day');
		}
		if (periodicna.length > 0 && daLiJePeriodicna) {
			for (let i = 0; i < periodicna.length; i++) {
				if (
					periodicna[i].semestar === trazeniSemestar &&
					periodicna[i].naziv === sala &&
					periodicna[i].pocetak === pocetak &&
					periodicna[i].kraj === kraj
				) {
					let trenutniDan = moment(new Date(2019, mjesec, 1));

					while (trenutniDan.day() !== periodicna[i].dan) {
						trenutniDan.add(1, 'day');
					}

					while (trenutniDan.month() == mjesec) {
						let indeksDana = trenutniDan.date() - 1;
						kalendarRef.children[indeksDana].children[1].classList.add('zauzeta');
						trenutniDan.add(7, 'day');
					}
				}
			}
		}
		if (vanredna.length > 0 && !daLiJePeriodicna) {
			for (let i = 0; i < vanredna.length; i++) {
				let vanredniDatum = moment(vanredna[i].datum, 'DD.MM.YYYY');

				if (
					vanredniDatum.month() == mjesec &&
					vanredna[i].naziv === sala &&
					vanredna[i].pocetak === pocetak &&
					vanredna[i].kraj === kraj
				) {
					let indeksDana = vanredniDatum.date() - 1;
					kalendarRef.children[indeksDana].children[1].classList.add('zauzeta');
				}
			}
		}
	}

	function daLiJePeriodicniTerminRezervisan(dan, semestar, pocetak, kraj, sala) {
		for (let i = 0; i < periodicna.length; i++) {
			if (
				periodicna[i].semestar === semestar &&
				periodicna[i].naziv === sala &&
				periodicna[i].pocetak === pocetak &&
				periodicna[i].kraj === kraj &&
				periodicna[i].dan === dan
			) {
				return true;
			}
		}
		return false;
	}
	function daLiJeVanredniTerminRezervisan(datum, pocetak, kraj, sala) {
		console.log(datum, sala, pocetak, kraj);
		for (let i = 0; i < vanredna.length; i++) {
			if (
				vanredna[i].datum === datum &&
				vanredna[i].naziv === sala &&
				vanredna[i].pocetak === pocetak &&
				vanredna[i].kraj === kraj
			) {
				return true;
			}
		}
		return false;
	}
	function ucitajPodatke(periodicniPodaci, vanredniPodaci) {
		periodicna = [];
		vanredna = [];
		for (var i = 0; i < periodicniPodaci.length; i++) {
			periodicna.push(periodicniPodaci[i]);
		}
		for (var i = 0; i < vanredniPodaci.length; i++) {
			vanredna.push(vanredniPodaci[i]);
		}
	}

	function kreirajDan(dan) {
		var time = document.createElement('time');
		time.setAttribute('datetime', dan.format('YYYY-MM-DD'));
		time.innerHTML = dan.get('date');
		var span = document.createElement('span'); 
		span.classList.add('slobodna'); 

		var button = document.createElement('button');
		button.classList.add('sedmica');
		button.id = dan.get('date');
		button.appendChild(time);
		button.appendChild(span); //
		button.addEventListener('click', function(event) {
			odabraniDan = event.target.id;
			if(odabraniDan == "") {
				odabraniDan = event.target.parentElement.id;
			}
			var inputPocetak = document.querySelector('#pocetak');
			var inputKraj = document.querySelector('#kraj');
			if (!!inputPocetak.value && !!inputKraj.value) {
				var rezervacija = {};
				let odabraniDanDatum = new Date(trenutnaGodina, trenutniMjesec, odabraniDan);
				if (daLiJePeriodicna) {
					let danUSedmici = odabraniDanDatum.getDay();
					if (danUSedmici == 0) danUSedmici = 7;
					rezervacija['dan'] = danUSedmici;

					let semestar = null;
					if ((trenutniMjesec >= 9 && trenutniMjesec <= 11) || trenutniMjesec == 0) {
						semestar = 'zimski';
					} else if (trenutniMjesec >= 1 && trenutniMjesec <= 5) {
						semestar = 'ljetni';
					}
					rezervacija['semestar'] = semestar;
				} else {
					rezervacija['datum'] = moment(odabraniDanDatum).format('DD.MM.YYYY');
				}

				rezervacija['pocetak'] = inputPocetak.value;
				rezervacija['kraj'] = inputKraj.value;
				rezervacija['naziv'] = imeOdabraneSale;
				rezervacija['predavac'] = 'Logovani profesor';

				// if (daLiJePeriodicna) {
				// 	if (
				// 		daLiJePeriodicniTerminRezervisan(
				// 			rezervacija['dan'],
				// 			rezervacija['semestar'],
				// 			rezervacija['pocetak'],
				// 			rezervacija['kraj'],
				// 			rezervacija['naziv']
				// 		)
				// 	) {
				// 		alert('Ovaj periodican termin je rezervisan!');
				// 		return;
				// 	}
				// } else {
				// 	if (
				// 		daLiJeVanredniTerminRezervisan(
				// 			rezervacija['datum'],
				// 			rezervacija['pocetak'],
				// 			rezervacija['kraj'],
				// 			rezervacija['naziv']
				// 		)
				// 	) {
				// 		alert('Ovaj vanredan termin je rezervisan!');
				// 		return;
				// 	}
				// }

				var rezervisi = confirm('Da li zelite da rezervisete termin?');
				if (rezervisi) {
					Pozivi.posaljiRezervaciju(
						rezervacija,
						function(rezultat) {
							Kalendar.ucitaj(rezultat.periodicniPodaci, rezultat.vanredniPodaci);
							provjeriInpute();
						},
						function(message) {
							alert(message);
						}
					);
				}
			}
		});
		return button;
	}
	function iscrtajKalendar(kalendarRef, mjesec) {
		kalendarRef.innerHTML = '';
		let godina = 2019;
		var prvi = new Date(godina, mjesec, 1);
		var danUSedmici = prvi.getDay();
		if (danUSedmici == 0) danUSedmici = 7; //korekcija za nedjelju
		var trenutni_dan = moment(prvi);

		let brojDanaUmjesecu = trenutni_dan.daysInMonth();

		for (let i = 1; i <= brojDanaUmjesecu; i++) {
			var dan = kreirajDan(trenutni_dan);
			if (i == 1) {
				dan.style.gridColumn = danUSedmici;
			}
			kalendarRef.appendChild(dan);
			trenutni_dan.add(1, 'day');
		}
	}

	return {
		oboji: obojiZauzeca,
		ucitaj: ucitajPodatke,
		iscrtaj: iscrtajKalendar
	};
})();

let periodicniPodaci = [];
let vanredniPodaci = [];

function generisiKalendar(godina, mjesec) {
	var dateGrid = document.getElementById('kalendar');
	dateGrid.innerHTML = '';

	var prvi = new Date(godina, mjesec, 1);
	var danUSedmici = prvi.getDay();
	if (danUSedmici == 0) danUSedmici = 7; //korekcija za nedjelju
	var trenutni_dan = moment(prvi);

	let brojDanaUmjesecu = trenutni_dan.daysInMonth();

	for (let i = 1; i <= brojDanaUmjesecu; i++) {
		var dan = kreirajDan(trenutni_dan);
		if (i == 1) {
			dan.style.gridColumn = danUSedmici;
		}
		dateGrid.appendChild(dan);
		trenutni_dan.add(1, 'day');
	}
}

function ubaciImeMjeseca(imeMjeseca, godina) {
	var divImeMjeseca = document.getElementById('imeMjeseca');
	divImeMjeseca.innerHTML = '';
	var span = document.createElement('span');
	span.innerHTML = imeMjeseca + ' ' + godina;
	divImeMjeseca.appendChild(span);
}
const monthNames = [
	'Januar',
	'Februar',
	'Mart',
	'April',
	'Maj',
	'Juni',
	'Juli',
	'August',
	'Septembar',
	'Oktobar',
	'Novembar',
	'Decembar'
];

var trenutniDatum = new Date();
var trenutniMjesec = trenutniDatum.getMonth();
var trenutnaGodina = trenutniDatum.getFullYear();
var kalendarRef = document.getElementById('kalendar');
var odabraniDan = null;
var imeOdabraneSale = null;
var daLiJePeriodicna = false;

function prethodniMjesec() {
	trenutniMjesec--;
	if (trenutniMjesec === -1) {
		trenutniMjesec = 11;
		trenutnaGodina--;
	}
	ubaciImeMjeseca(monthNames[trenutniMjesec], trenutnaGodina);
	Kalendar.iscrtaj(kalendarRef, trenutniMjesec);
	provjeriInpute();
}

function sljedeciMjesec() {
	trenutniMjesec++;
	if (trenutniMjesec === 12) {
		trenutniMjesec = 0;
		trenutnaGodina++;
	}
	ubaciImeMjeseca(monthNames[trenutniMjesec], trenutnaGodina);
	Kalendar.iscrtaj(kalendarRef, trenutniMjesec);
	provjeriInpute();
}
const provjeriInpute = function() {
	var inputPocetak = document.querySelector('#pocetak');
	var inputKraj = document.querySelector('#kraj');
	if (!!inputPocetak.value && !!inputKraj.value) {
		Kalendar.oboji(kalendarRef, trenutniMjesec, imeOdabraneSale, inputPocetak.value, inputKraj.value);
	}
};
window.addEventListener('DOMContentLoaded', function(event) {
	var prethodniButton = document.querySelector('#prethodniButton');
	prethodniButton.addEventListener('click', function(event) {
		prethodniMjesec();
	});
	var sljedeciButton = document.querySelector('#sljedeciButton');
	sljedeciButton.addEventListener('click', function(event) {
		sljedeciMjesec();
	});

	var selectListaSala = document.querySelector('#listaSala');
	var checkboxPeriodicna = document.querySelector('#periodicna');
	imeOdabraneSale = selectListaSala.options[selectListaSala.selectedIndex].text;
	daLiJePeriodicna = checkboxPeriodicna.checked;

	var inputPocetak = document.querySelector('#pocetak');
	var inputKraj = document.querySelector('#kraj');

	inputPocetak.onchange = provjeriInpute;
	inputKraj.onchange = provjeriInpute;
	selectListaSala.onchange = function() {
		imeOdabraneSale = selectListaSala.options[selectListaSala.selectedIndex].text;
		provjeriInpute();
	};
	checkboxPeriodicna.onchange = function() {
		daLiJePeriodicna = this.checked;
		provjeriInpute();
	};

	Pozivi.dajRezervacije(function(rezultat) {
		Kalendar.ucitaj(rezultat.periodicniPodaci, rezultat.vanredniPodaci);
	});

	Kalendar.iscrtaj(kalendarRef, trenutniMjesec);
	ubaciImeMjeseca(monthNames[trenutniMjesec], trenutnaGodina);
});
