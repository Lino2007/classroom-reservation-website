let Pozivi = (function() {
	function dajRezervacije(callback) {
		var xhttp = new XMLHttpRequest();
		xhttp.onreadystatechange = function() {
			if (this.readyState == 4 && this.status == 200) {
				let rezultat = JSON.parse(this.responseText); // dobijam rezultat sa servera
				callback(rezultat);
			}
		};
		xhttp.open('GET', 'http://localhost:8080/api', true);
		xhttp.send();
	}

	function posaljiRezervaciju(rezervacija, fnCallback, errCallback) {
		var ajax = new XMLHttpRequest();
		ajax.onreadystatechange = function() {
			if (ajax.readyState == 4 && ajax.status == 200) {
				var jsonRez = JSON.parse(ajax.responseText); // dobijam rezultat sa servera
				if (jsonRez.hasOwnProperty('message')) {
					errCallback(jsonRez['message']);
				} else {
					fnCallback(jsonRez);
				}
			}
		};
		ajax.open('POST', 'http://localhost:8080/', true);
		ajax.setRequestHeader('Content-Type', 'application/json');
		ajax.send(JSON.stringify(rezervacija));
	}

	function dajSlike(callback) {
		var xhttp = new XMLHttpRequest();
		xhttp.onreadystatechange = function() {
			if (this.readyState == 4 && this.status == 200) {
				let rezultat = JSON.parse(this.responseText);
				callback(rezultat);
			}
		};
		xhttp.open('GET', 'http://localhost:8080/slike/', true);
		xhttp.send();
	}

	return {
		dajRezervacije: dajRezervacije,
		posaljiRezervaciju: posaljiRezervaciju,
		dajSlike: dajSlike
	};
})();

export default Pozivi;