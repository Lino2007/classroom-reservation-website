const express = require('express');
const bodyParser = require('body-parser');
const moment = require('moment')
const fs = require('fs');
const PORT = 8080;
const app = express();
const userAgent = require('useragent');
const IP = require('ip');
const folderSlike = './public/slike/';

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static(__dirname + '/public'));


app.get('/', function(req, res) {
	res.sendFile('./public/pocetna.html', { root: __dirname });
});

app.get('/api', function(req, res) {
	let rawdata = fs.readFileSync('zauzeca.json');
	res.header('Content-Type', 'application/json');
	res.send(rawdata);
});

function daLiJePeriodicniTerminRezervisan(periodicna, dan, semestar, pocetak, kraj, sala) {
	for (let i = 0; i < periodicna.length; i++) {
		if (
			periodicna[i].semestar === semestar &&
			periodicna[i].naziv === sala &&
			periodicna[i].pocetak === pocetak &&
			periodicna[i].kraj === kraj &&
			periodicna[i].dan === dan
		) {
			return true;
		}
	}
	return false;
}
function daLiJeVanredniTerminRezervisan(vanredna, datum, pocetak, kraj, sala) {
	for (let i = 0; i < vanredna.length; i++) {
		if (
			vanredna[i].datum === datum &&
			vanredna[i].naziv === sala &&
			vanredna[i].pocetak === pocetak &&
			vanredna[i].kraj === kraj
		) {
			return true;
		}
	}
	return false;
}

app.post('/', function(req, res) {
	let rawdata = fs.readFileSync('zauzeca.json');
	let rezervacije = JSON.parse(rawdata);
	let rezervacija = req.body;

	if (rezervacija.hasOwnProperty('datum')) {
		if (
			daLiJeVanredniTerminRezervisan(
				rezervacije.vanredniPodaci,
				rezervacija['datum'],
				rezervacija['pocetak'],
				rezervacija['kraj'],
				rezervacija['naziv']
			)
		) {
            let formatiranDatum = moment(rezervacija['datum'], 'DD.MM.YYYY').format('DD/MM/YYYY')
            res.send({ message: 'Nije moguće rezervisati salu '+rezervacija['naziv']+' za navedeni datum '+formatiranDatum +
            ' i termin od '+rezervacija['pocetak']+' do '+rezervacija['kraj']+'!' });
		} else {
			rezervacije.vanredniPodaci.push(rezervacija);
		}
	} else {
		if (
			daLiJePeriodicniTerminRezervisan(
				rezervacije.periodicniPodaci,
				rezervacija['dan'],
				rezervacija['semestar'],
				rezervacija['pocetak'],
				rezervacija['kraj'],
				rezervacija['naziv']
			)
		) {
			//let formatiranDatum = moment().format('DD/MM/YYYY') KAKO ?????
            res.send({ message: 'Nije moguće rezervisati salu '+ rezervacija['naziv'] + ' za navedeni datum' +
            ' i termin od '+ rezervacija['pocetak']+' do '+ rezervacija['kraj'] +'!' });
		} else {
			rezervacije.periodicniPodaci.push(rezervacija);
		}
	}

	fs.writeFileSync('zauzeca.json', JSON.stringify(rezervacije));
	res.send(rezervacije);
});

app.get('/slike/', function(req, res) {
	var brojac = 0;
	var path = './slike/';
	var slike = [];

	fs.readdir(folderSlike, (err, files) => {
		files.forEach(element => brojac++);
	  	 for(var i = 0; i < brojac; i++) {
	      	slike.push(path + files[i]);
	 	 }
	});

	setTimeout(function(){ 
		res.send({
			slike: slike,
			brojStranica: Math.ceil(slike.length / 3)
		});

	 }, 500);
});

app.get('/stats', function(req, res) {
	var usersIP = IP.address();
	let rawdata = fs.readFileSync('./stats.json');
	res.header('Content-Type', 'application/json');
	let stats = JSON.parse(rawdata);
	var browser = userAgent.parse(req.headers['user-agent']);
	if (browser.family == 'Firefox') {
		stats.firefox = stats.firefox + 1;
	}
	if (browser.family == 'Chrome') {
		stats.chrome = stats.chrome + 1;
	}
	if (!stats.ip_addresses.includes(usersIP)) {
		stats.ip_addresses_count = stats.ip_addresses_count + 1;
		stats.ip_addresses.push(usersIP);
	}

	fs.writeFileSync("./stats.json", JSON.stringify(stats));
	res.send(stats);
});

app.listen(PORT, () => {
	console.log('Listening on http://localhost:' + PORT + '/ port!');
});
