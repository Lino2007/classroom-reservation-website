let Pozivi = (function(){
  //privatni
  //metode
  function ucitajZauzecaAjaxImpl(){
    var ajax=new XMLHttpRequest();
    ajax.onreadystatechange=function(){
      if (ajax.readyState == 4 && ajax.status == 200){
        let obj,per,van;
        console.log("Na pocetku ucitani podaci: "+ajax.responseText);
        obj=JSON.parse(ajax.responseText);
        per=obj.periodicna;
        van=obj.vanredna;
        Kalendar.ucitajPodatke(per,van);
      }
      if (ajax.readyState == 4 && ajax.status == 404)
        console.log('greska 404');
    }
    ajax.open("GET", "zauzeca.json", true);
    ajax.send();
  }
  function upisiZauzeceAjaxImpl(divKalendar,period,oDanSedmica,oDanMjesec,oMjesec,oSemestar,oDatum,oPocetak,oKraj,oSala,oPredavac){
    console.log("zahtjev za upis: "+period+" "+oDanSedmica+" "+oDanMjesec+" "+oMjesec+" "+oSemestar+" "+oDatum+" "+oPocetak+" "+oKraj+" "+oSala+" "+oPredavac);
    //provjera da li postoji zauzece
    var ajax=new XMLHttpRequest();
    ajax.onreadystatechange=function(){
      if (ajax.readyState == 4 && ajax.status == 200){
        let odg=ajax.responseText,obj,per,van;
        //nastaviti,2 slucaja
        if(odg.charAt(0)=='{'){
          console.log('da');
          obj=JSON.parse(ajax.responseText);
          per=obj.periodicna;
          van=obj.vanredna;
          Kalendar.ucitajPodatke(per,van);
          Kalendar.obojiZauzeca(divKalendar,oMjesec,oSala,oPocetak,oKraj);
        }
        else{
          alert(ajax.responseText);
          Kalendar.obojiZauzeca(divKalendar,oMjesec,oSala,oPocetak,oKraj);
        }
        console.log("ajax odgovor"+ajax.responseText);
      }
      if (ajax.readyState == 4 && ajax.status == 404)
        console.log('greska 404');
    }
    ajax.open("POST", "http://localhost:8080/zauzeca.json", true);
    ajax.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
    ajax.send("period="+period+"&oDanSedmica="+oDanSedmica+"&oDanMjesec="+oDanMjesec+"&oMjesec="+oMjesec+"&oSemestar="+oSemestar+"&oDatum="+oDatum+"&oPocetak="+oPocetak+"&oKraj="+oKraj+"&oSala="+oSala+"&oPredavac="+oPredavac);
  }
  function ucitajSlikeAjaxImpl(divGrid,redniBroj){
    var ajax=new XMLHttpRequest();
    ajax.onreadystatechange=function(){
      if (ajax.readyState == 4 && ajax.status == 200){
        let odg=ajax.responseText;console.log(ajax.responseText);
        odg=odg.split(',');
        slika1.src=odg[1];console.log(odg[1]);
        prethodne.push(odg[1]);
        if(odg[0]=='<') {}
        else if(odg[0]=='0' || odg[0]=='>') {
          slika2.src=odg[2];
          prethodne.push(odg[2]);
          slika3.src=odg[3];
          prethodne.push(odg[3]);
          if(odg[0]=='0') {
            dpSljedeci.disabled=true;
            sveUcitane=true;
          }
        }
        else if(odg[0]=='-1'){
          slika2.src=odg[2];
          prethodne.push(odg[2]);
          slika3.src="";
          slika3.style.display="none";
          dpSljedeci.disabled=true;
          sveUcitane=true;maxRedniBroj=redniBroj;
          prikazanaJedna=false;prikazaneDvije=true;
          divGrid.classList.remove("klasaJedna");
          divGrid.classList.add("klasaDvije");
        }
        else {
          slika2.src="";
          slika2.style.display="none";
          slika3.src="";
          slika3.style.display="none";
          dpSljedeci.disabled=true;
          sveUcitane=true;maxRedniBroj=redniBroj;
          prikazanaJedna=true;prikazaneDvije=false;
          divGrid.classList.add("klasaJedna");
          divGrid.classList.remove("klasaDvije");
        }
      }
      if (ajax.readyState == 4 && ajax.status == 404)
        console.log('greska 404');
    }
    ajax.open("GET", "/slike?br="+redniBroj, true);
    ajax.send();
  }
return {
ucitajZauzecaAjax: ucitajZauzecaAjaxImpl,
upisiZauzeceAjax:upisiZauzeceAjaxImpl,
ucitajSlikeAjax:ucitajSlikeAjaxImpl
}
}());
