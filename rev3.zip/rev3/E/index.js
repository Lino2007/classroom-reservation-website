const express=require('express');
const bodyParser=require('body-parser');
const url=require('url');
const fs=require('fs');
const app=express();
const prviDaniMjesec=[2,5,5,1,3,6,1,4,7,2,5,7];//pon-1...
const cacheTime = 86400000 * 30;

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));
app.use('/slike',express.static(__dirname+'/slike',{maxAge: cacheTime}));//ne treba nista sakriti
app.use('/style',express.static(__dirname+'/style'));
app.use('/js',express.static(__dirname+'/js'));

app.get('/',function(req,res){
  res.sendFile(__dirname+'/pocetna.html');
});
app.get('/pocetna.html',function(req,res){
  res.sendFile(__dirname+'/pocetna.html');
});
app.get('/rezervacija.html',function(req,res){
  res.sendFile(__dirname+'/rezervacija.html');
});
app.get('/sale.html',function(req,res){
  res.sendFile(__dirname+'/sale.html');
});
app.get('/testoviS2.html',function(req,res){
  res.sendFile(__dirname+'/testoviS2.html');
});
app.get('/unos.html',function(req,res){
  res.sendFile(__dirname+'/unos.html');
});
app.get('/zauzeca.json',function(req,res){
  res.sendFile(__dirname+'/zauzeca.json');
});
app.get('/1.png',function(req,res){
  res.sendFile(__dirname+'/1.png');
});
//bolje sa post valjda, sigurnost..
app.post('/zauzeca.json',function(req,res){
  //console.log("aaaaaaaaaaaaaaaaa");
  let tijelo=req.body,period=true;
  if(tijelo['period']=='false') period=false;
  fs.readFile(__dirname+'/zauzeca.json',function(err,data){
    //console.log("aaaaaaaaaaaaaaaaa");
    if (err) return console.error(err);

    let odg=data.toString();
    let obj=JSON.parse(odg),nalazi=false,z,per,van;
    per=obj.periodicna;
    van=obj.vanredna;

    let zDanSedmica,zDanMjesec,zMjesec,zSemestar,zDatum,zPocetak,zPocetakH,zPocetakM,zKraj,zKrajH,zKrajM,zSala,zPredavac;
    let oDanSedmica=tijelo['oDanSedmica'],oDanMjesec=tijelo['oDanMjesec'],oMjesec=tijelo['oMjesec'],oSemestar=tijelo['oSemestar'];
    let oDatum=tijelo['oDatum'],oPocetak=tijelo['oPocetak'],oKraj=tijelo['oKraj'],oSala=tijelo['oSala'],oPredavac=tijelo['oPredavac'];
    let bPocetak=oPocetak,bKraj=oKraj;
    //oDanSedmica je od 1, dok oMjesec od 0

    oPocetak=oPocetak.split(":");
    oKraj=oKraj.split(":");
    let oPocetakH=parseInt(oPocetak[0]),oPocetakM=parseInt(oPocetak[1]),oKrajH=parseInt(oKraj[0]),oKrajM=parseInt(oKraj[1]);

    //da je oPocetak<oKraj testirat cemo u browseru
    for(let i=0;i<per.length;i++){
      z=per[i];
      zDanSedmica=z.dan+1;zSemestar=z.semestar;zPocetak=z.pocetak;zKraj=z.kraj;zSala=z.naziv;zPredavac=z.predavac;
      //zDanSedmica je od 1-uvecali

      zPocetak=zPocetak.split(":");
      zKraj=zKraj.split(":");
      zPocetakH=parseInt(zPocetak[0]);
      zPocetakM=parseInt(zPocetak[1]);
      zKrajH=parseInt(zKraj[0]);
      zKrajM=parseInt(zKraj[1]);
      //mozda je bolje zbog efikasnosti ovo izvan, ali ovako manje pisanja
      //dodat pretvaranja u int-vidjet kasnije zbog automatske konverzije..
      if(period){
        if(oSala==zSala && oPredavac==zPredavac && oSemestar==zSemestar && oDanSedmica==zDanSedmica &&
          !((zKrajH<oPocetakH || zKrajH==oPocetakH && zKrajM<=oPocetakM)||(oKrajH<zPocetakH || oKrajH==zPocetakH && oKrajM<=zPocetakM))){
          nalazi=true;
          break;
        }
      }
      else{
        if(oSala==zSala && oPredavac==zPredavac && oDanSedmica==zDanSedmica &&
          !((zKrajH<oPocetakH || zKrajH==oPocetakH && zKrajM<=oPocetakM)||(oKrajH<zPocetakH || oKrajH==zPocetakH && oKrajM<=zPocetakM))&&
          (zSemestar=="zimski" && (oMjesec>=9 && oMjesec <=11 || oMjesec==0) || zSemestar=="ljetni" && oMjesec>=1 && oMjesec <=5)){
          nalazi=true;
          break;
        }
      }
    }
    //
    if(nalazi){
      oDatum=oDatum.split('.');
      res.send("Nije moguće rezervisati salu "+oSala+" za navedeni datum "+oDatum[0]+"/"+oDatum[1]+"/"+oDatum[2]+" i termin od "+bPocetak+" do "+bKraj+"!");
    }
    //
    for(let i=0;i<van.length;i++){
      z=van[i];
      zDatum=z.datum;zSemestar=z.semestar;zPocetak=z.pocetak;zKraj=z.kraj;zSala=z.naziv;zPredavac=z.predavac;
      zDatum=zDatum.split(".");
      zDanMjesec=parseInt(zDatum[0]);
      //zMjesec=parseInt(zDatum[1]);//sad ne umanjujemo,zasto sam to napisao-valjda kad sam mislio da cu samo datum slati kao parametar, treba umanjiti
      zMjesec=parseInt(zDatum[1])-1;

      zPocetak=zPocetak.split(":");
      zKraj=zKraj.split(":");
      zPocetakH=parseInt(zPocetak[0]);
      zPocetakM=parseInt(zPocetak[1]);
      zKrajH=parseInt(zKraj[0]);
      zKrajM=parseInt(zKraj[1]);

      //let xI=zDanMjesec+prviDaniMjesec[zMjesec-1]-1;
      let xI=zDanMjesec+prviDaniMjesec[zMjesec]-1;

      zDanSedmica=xI%7;
      if(zDanSedmica==0) zDanSedmica=7;
      //zDanSedmica je od 1

      if(period){
        if(oSala==zSala && oPredavac==zPredavac && oDanSedmica==zDanSedmica &&
          !((zKrajH<oPocetakH || zKrajH==oPocetakH && zKrajM<=oPocetakM)||(oKrajH<zPocetakH || oKrajH==zPocetakH && oKrajM<=zPocetakM))&&
          (oSemestar=="zimski" && (zMjesec>=9 && zMjesec <=11 || zMjesec==0) || oSemestar=="ljetni" && zMjesec>=1 && zMjesec <=5)){
          console.log('ne more, postoji zauzece '+zDatum[0]+'.'+zDatum[1]);
          nalazi=true;
          break;
        }
      }
      else{
        if(oSala==zSala && oPredavac==zPredavac && oDanMjesec==zDanMjesec && oMjesec==zMjesec &&
          !((zKrajH<oPocetakH || zKrajH==oPocetakH && zKrajM<=oPocetakM)||(oKrajH<zPocetakH || oKrajH==zPocetakH && oKrajM<=zPocetakM))){
          nalazi=true;
          break;
        }
      }
    }
    if(nalazi){
      oDatum=oDatum.split('.');
      res.send("Nije moguće rezervisati salu "+oSala+" za navedeni datum "+oDatum[0]+"/"+oDatum[1]+"/"+oDatum[2]+" i termin od "+bPocetak+" do "+bKraj+"!");
    }
    else{
      if(period){
        let objekat={dan:oDanSedmica-1, semestar:oSemestar, pocetak:bPocetak, kraj:bKraj,naziv:oSala,predavac:oPredavac};
        obj.periodicna.push(objekat);
        let objTekst=JSON.stringify(obj);
        fs.writeFile('zauzeca.json', objTekst, function (err) {
          if (err) throw err;
          console.log('Replaced! periodicni ubacen');
          res.sendFile(__dirname+'/zauzeca.json');
        });
      }
      else{
        let objekat={datum:oDatum, pocetak:bPocetak, kraj:bKraj,naziv:oSala,predavac:oPredavac};
        obj.vanredna.push(objekat);
        let objTekst=JSON.stringify(obj);
        fs.writeFile('zauzeca.json', objTekst, function (err) {
          if (err) throw err;
          console.log('Replaced! vanredni ubacen');
          res.sendFile(__dirname+'/zauzeca.json');
        });
      }
    }
  });
});
//dakle ne trebaju niti staticke?
app.get('/slike',function(req,res){
  //console.log("sad");
  fs.readdir(__dirname+'/slike', function(err,files){
    let redniBr=parseInt(req.query.br);
    let brSlika=files.length;
    let odg;

    //vidjet jos ako pritisne sljedeci a jos se nisu ucitale zadnje slike-mozemo ukodirat u poruku pa prepravit il poslat zathyjev prije
    //for(let i=0;i<brSlika;i++) console.log(files[i]);
    if(brSlika-(redniBr+1)*3<-2) res.send('<,slike/');
    else if(brSlika-(redniBr+1)*3==-2) res.send('-2,slike/'+files[redniBr*3]);
    else if(brSlika-(redniBr+1)*3==-1) res.send('-1,slike/'+files[redniBr*3]+','+'slike/'+files[redniBr*3+1]);
    else if(brSlika-(redniBr+1)*3==0) res.send('0,slike/'+files[redniBr*3]+','+'slike/'+files[redniBr*3+1]+','+'slike/'+files[redniBr*3+2]);
    else if(brSlika-(redniBr+1)*3>0) res.send('>,slike/'+files[redniBr*3]+','+'slike/'+files[redniBr*3+1]+','+'slike/'+files[redniBr*3+2]);
  });
})

app.listen(8080);
