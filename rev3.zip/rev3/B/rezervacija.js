function ucitaj() {
    Pozivi.ucitajPodatke();
    ucitajKalendar();
}