const express = require("express");
const bodyParser = require("body-parser");
const fs = require("fs");
const app = express();

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({extended : true}));
app.use(express.static(__dirname+'/public'));
app.get("/", function(req,res){
    res.sendFile("/public/html/pocetna.html", {root : __dirname});
});
app.get("/pocetna.html", function(req,res){
    res.sendFile("/public/html/pocetna.html", {root : __dirname});
});
app.get("/sale.html", function(req,res){
    res.sendFile("/public/html/sale.html", {root : __dirname});
});
app.get("/unos.html", function(req,res){
    res.sendFile("/public/html/unos.html", {root : __dirname});
});
app.get("/rezervacija.html", function(req,res){
    res.sendFile("/public/html/rezervacija.html", {root : __dirname});
});
app.post("/json/zauzeca.json", function(req, res){
    let obj = req.body;

    //obj je novo zauzece, zavisno od toga koje je vrste dodaje se na tu listu i sve se ponovo upisuje u json
    let data = JSON.parse(fs.readFileSync(__dirname+"/public/json/zauzeca.json"));
    if(obj["dan"] != "" && obj["dan"] != null){
        obj["dan"] = parseInt(obj["dan"]);
        for(var i = 0; i <data.periodicna.length; i++){
            /*if(JSON.stringify(data.periodicna[i])== JSON.stringify(obj)){
                res.status(400).send("Postoji zauzece");
            }*/
            let podaci = data.periodicna[i];
            if(podaci.naziv == obj.naziv){
                if(podaci.dan == obj.dan){
                    let pocetak = parseTime(podaci.pocetak);
                    let kraj = parseTime(podaci.kraj);
                    let pocetakObj = parseTime(obj.pocetak);
                    let krajObj = parseTime(obj.kraj);
                    let razdvojeni = ((pocetak<=pocetakObj && kraj <=pocetakObj) ||(pocetakObj<=pocetak && krajObj<=pocetak));
                    if(!razdvojeni){
                        res.status(400).send("Postoji zauzece");
                    }
                }
            }            
        }

        data.periodicna.push(obj);
    }
    else{
        for(var i = 0; i <data.periodicna.length; i++){
            /*if(JSON.stringify(data.periodicna[i])== JSON.stringify(obj)){
                res.status(400).send("Postoji zauzece");
            }*/
            let podaci = data.periodicna[i];
            if(podaci.naziv == obj.naziv){
                let danSedmice = dajDan(parseDate(obj.datum));
                if(podaci.dan == danSedmice){
                    let pocetak = parseTime(podaci.pocetak);
                    let kraj = parseTime(podaci.kraj);
                    let pocetakObj = parseTime(obj.pocetak);
                    let krajObj = parseTime(obj.kraj);
                    let razdvojeni = ((pocetak<=pocetakObj && kraj <=pocetakObj) ||(pocetakObj<=pocetak && krajObj<=pocetak));
                    if(!razdvojeni){
                        res.status(400).send("Postoji zauzece");
                    }
                }
            }            
        }
        for(var i = 0; i <data.vanredna.length; i++){
            /*if(JSON.stringify(data.vanredna[i])== JSON.stringify(obj)){
                res.status(400).send("Postoji zauzece");
            }*/
            let podaci = data.periodicna[i];
            if(podaci.naziv == obj.naziv){
                if(podaci.datum == obj.datum){
                    let pocetak = parseTime(podaci.pocetak);
                    let kraj = parseTime(podaci.kraj);
                    let pocetakObj = parseTime(obj.pocetak);
                    let krajObj = parseTime(obj.kraj);
                    let razdvojeni = ((pocetak<=pocetakObj && kraj <=pocetakObj) ||(pocetakObj<=pocetak && krajObj<=pocetak));
                    if(!razdvojeni){
                        res.status(400).send("Postoji zauzece");
                    }
                }
            } 
        }
        data.vanredna.push(obj);
    }
    fs.writeFileSync(__dirname+"/public/json/zauzeca.json", JSON.stringify(data));
    res.status(200);
    res.send("OK");
})
app.get("/slike/", function(req,res){;
    var dirList = [];
    var broj = parseInt(req.query["broj"]);
    //ucitavanje liste slike i prosljedivanje one po redu koja je sljedeca ili prazan string
    fs.readdir(__dirname+"/public/slike", function(err, items){
        dirList = items;
        if(items.length > broj){
            res.send(items[broj]);
        }
        else{
            res.send("");
        }
    });
});

app.listen(8080);

function parseDate(string){
    var regex = /(\d{1,2}.\d{1,2}.\d{4})/;
    var items = string.match(regex);
    let datum  = new Date(items[2], items[1]-1, items[0]);
    return datum;
}
function dajDan(datum){
    let danSedmice;
    (datum.getDay() == 0) ? danSedmice = 6: danSedmice = datum.getDay()-1;
    return danSedmice;
}
function parseTime(string){
    var regex = /(\d{2}-\d{2})/;
    var items = string.match(regex);
    let datum = new Date(2019,1,1,items[0], items[1]);
    return datum;
}