let Pozivi = (function(){
    let ajax = new XMLHttpRequest();
    let slike = [];
    let periodicnaZauzeca = [];
    let vanrednaZauzeca = [];
    function ucitajZauzecasaServeraImpl(fnCallback){

        //preuzimanje zauzeca sa servera
        $.getJSON("../json/zauzeca.json", function(data){
            periodicnaZauzeca = data.periodicna;
            vanrednaZauzeca = data.vanredna;
            fnCallback(periodicnaZauzeca, vanrednaZauzeca);
        });
    }
    function rezervisiTerminImpl(dan, mjesec, redovno, pocetak, kraj, naziv, predavac){
        let datum = new Date(2019, mjesec, dan);
        let danSedmice;
        let obj = new Object();
        //kreiranje objekta novog zauzeca, objekat se prosljeduje post metodi umjesto rucnog ubacivanja kao url
        (datum.getDay() == 0) ? danSedmice = 6: danSedmice = datum.getDay()-1;
        if(redovno){
            obj.dan = danSedmice;
            (ljetniSemestar.includes(mjesec)? obj.semestar = "ljetni" : obj.semestar = "zimski");
        }
        else{
            mjesec = mjesec+1;
            if(dan<10) dan = "0"+dan;
            if(mjesec<10) mjesec = "0"+mjesec;
            obj.datum = dan+"."+mjesec+".2019";
            mjesec = parseInt(mjesec)-1;
        }
        obj.pocetak = pocetak;
        obj.kraj = kraj;
        obj.naziv = naziv;
        obj.predavac = predavac;
        if(redovno) periodicnaZauzeca.push(obj);
        else vanrednaZauzeca.push(obj);
        //rewrite json

        //post novog zauzeca
        $.ajax({
            url : "/json/zauzeca.json",
            method: "POST",
            //contentType : "application/json",
            dataType: "text",
            data : obj,
            success : function(response){
                let kalRef = document.getElementById("kalendar");
                let sala = document.getElementById("sala").value;
                let pocetak = document.getElementById("pocetak").value;
                let kraj = document.getElementById("kraj").value;
                Pozivi.ucitajZauzecasaServera(Kalendar.ucitajPodatke);
                osvjezi(kalRef, sala, pocetak, kraj);
            },
            error : function(response){
                alert("Nije moguće rezervisati salu "+naziv+" za navedeni datum "+dan+"/"+(mjesec+1)+"/2019 i termin od "+pocetak+" do "+kraj+"!");
            }
            
        });
        
    }
    function ucitajPrethodneSlikeImp(prva){
        prva = prva.split("http://localhost:8080/").pop();
        var offset = slike.indexOf(prva);
        if(offset >2){
            $("#galerija div").each(function(index){
                $(this).empty();
                $(this).append("<img src="+slike[offset-3+index]+">");
            });
        }
    }
    function ucitajSlikeImpl(prva){

       //poziva sinhrono iako je nepreporucljivo da ne bi dohvatio 3 puta istu sliku, mozda ispravim
        var offset = -1;
        if(slike.length != 0){
            prva = prva.split("http://localhost:8080/").pop();
            offset = slike.indexOf(prva);
        }

        if(slike.length == 0 || offset >= slike.length-3){
            for(var i = 0; i < 3; i++){
                $.ajax({
                    url: "/slike",
                    method: "GET",
                    dataType: "text",
                    async: false,
                    data: {broj: slike.length},
                    success : function(data, status){
                        if(data != ""){
                            slike.push("slike/"+data);
                        }
                        else{
                            slike.push("");
                        }
                    }
                })
                if(i==0 && slike[slike.length-1] == ""){
                    slike.pop();
                    return;
                }
            }
            //dodavanje slika u div elemente
            $("#galerija div").each(function(index){
                $(this).empty();
                if(slike[slike.length-(3-index)] != "") $(this).append("<img src="+slike[slike.length-(3-index)]+">");
            });
        }
        else{
            //console.log(offset);
            $("#galerija div").each(function(index){
                $(this).empty();
                if(slike[offset+3+index] != "") $(this).append("<img src="+slike[offset+3+index]+">");
            });
        }
        
    }
    return {
        ucitajZauzecasaServera : ucitajZauzecasaServeraImpl,
        ucitajSlike : ucitajSlikeImpl,
        ucitajPrethodneSlike : ucitajPrethodneSlikeImp,
        rezervisiTermin : rezervisiTerminImpl
    }
}());
