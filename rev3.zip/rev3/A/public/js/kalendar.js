let primjer1 = [{ dan : 0, semestar : "zimski", pocetak : "10:00",kraj : "11:00",    naziv : "1-02", predavac : "Irfan"},
                { dan : 4, semestar : "zimski", pocetak : "10:00",kraj : "11:00",    naziv : "1-02", predavac : "Irfan"},
                { dan : 0, semestar : "ljetni", pocetak : "10:00",kraj : "11:00",    naziv : "1-02", predavac : "Irfan"}];

let primjer2 = [{ datum : "18.11.2019", pocetak : "10:00", kraj : "11:00", naziv : "1-02", predavac : "Irfan"},
                { datum : "27.11.2019", pocetak : "10:00", kraj : "11:00", naziv : "1-02", predavac : "Irfan"},
                { datum : "27.10.2019", pocetak : "10:00", kraj : "11:00", naziv : "1-02", predavac : "Irfan"},
                { datum : "25.12.2019", pocetak : "10:00", kraj : "11:00", naziv : "1-02", predavac : "Irfan"}];


let ljetniSemestar = [1,2,3,4,5];
let zimskiSemestar = [0,9,10,11];

let Kalendar = (function(){
    //
    //ovdje idu privatni atributi
    //
    let listaRedovna = [];
    let listaVanredna = []; 

    function obojiZauzecaImpl(kalendarRef, mjesec, sala, pocetak, kraj){
        if(listaVanredna.length == 0 && listaRedovna.length == 0) return;
        if(sala == "" || pocetak =="" || kraj =="") return;
        var dani = kalendarRef.children[2];
        var zauzetiDani;
        Kalendar.iscrtajKalendar(kalendarRef, mjesec);
        if(listaRedovna.length != 0){
            listaRedovna.forEach(element => {
                if(element.naziv == sala){
                    if(odgovarajuciSemestar(element.semestar, mjesec)){
                        if(ukljucujeTermin(pocetak, kraj, element.pocetak, element.kraj)){
                            var offsetDana = getOffset(mjesec, element.dan);
                            zauzetiDani = dani.querySelectorAll(`.dan:nth-child(7n+${offsetDana+1})`);
                            zauzetiDani.forEach(element =>{
                                if(element.children[1].classList.contains("slobodna")){
                                    element.children[1].classList.remove("slobodna");
                                    element.children[1].classList.add("zauzeta");
                                }
                            });
                        }
                    }
                }
            });
        }
        if(listaVanredna.length != 0){
            listaVanredna.forEach(element =>{
                if(element.naziv == sala){
                    if(odgovarajuciMjesec(element.datum, mjesec)){
                        if(ukljucujeTermin(pocetak, kraj, element.pocetak, element.kraj)){
                            var dan = dani.children[parseInt(element.datum.substring(0,3))-1];
                            if(dan.children[1].classList.contains("slobodna")){
                                dan.children[1].classList.remove("slobodna");
                                dan.children[1].classList.add("zauzeta");
                            }
                        }
                    }
                }
            });
        }
    }
    function ucitajPodatkeImpl(periodicna, vanredna){
        if(listaRedovna.length != 0) listaRedovna = [];
        if(listaVanredna.length != 0) listaVanredna = [];
        periodicna.forEach(element=>{
            if(validanPeriodicniElement(element)){
                listaRedovna.push(element);
            }
        });
        vanredna.forEach(element=>{
            if(validanVanredniElement(element)){
                listaVanredna.push(element);
            }
        });
    }
    function iscrtajKalendarImpl(kalendarRef, mjesec){
        var screenSize = window.matchMedia("(max-width: 600px)")
        let datum = new Date(2019, mjesec);
        let trenutna = ((datum.getDay()==0)? 7 : datum.getDay());
        let dani = kalendarRef.children[2];
        kalendarRef.children[0].innerHTML = dajNazivMjeseca(mjesec);
        dani.innerHTML = "";
        while(datum.getMonth() == mjesec){
            var div = document.createElement("div");
            div.classList.add("dan");
            var broj = document.createElement("div");
            broj.classList.add("broj")
            broj.innerHTML = datum.getDate();
            var zauzece = document.createElement("div");
            zauzece.classList.add("slobodna");
            if(datum.getDate() === 1){
                if(screenSize.matches){
                    ((datum.getDay() == 0) ? div.style.gridRow = 7: div.style.gridRow = datum.getDay());
                    div.style.gridColumn = "auto";
                }
                else{
                    ((datum.getDay() == 0) ? div.style.gridColumn = 7: div.style.gridColumn = datum.getDay());
                    div.style.gridRow = "auto";
                }
            }
            if(trenutna<=7){
                div.classList.add("trenutnaSedmica");
                trenutna++;
            }
            div.appendChild(broj);
            div.appendChild(zauzece);
            dani.appendChild(div);
            datum.setDate(datum.getDate()+1);
        }
        dodajClickListenere();
    }
    function osvjeziPoziv(kalendar, sala, pocetak, kraj){
        osvjezi(kalendar, sala, pocetak, kraj);
    }
    return {
    obojiZauzeca: obojiZauzecaImpl,
    ucitajPodatke: ucitajPodatkeImpl,
    iscrtajKalendar: iscrtajKalendarImpl,
    osvjezi : osvjeziPoziv
    }
}());

//primjer korištenja modula
//Kalendar.obojiZauzeca(document.getElementById("kalendar"),1,"1-15","12:00","13:30");
//Kalendar.ucitajPodatke(primjer1, primjer2);



function osvjezi(kalendar, sala, pocetak, kraj){
    var mjesec = dajBrojTrenutnogMjeseca(kalendar);
    Kalendar.iscrtajKalendar(kalendar, mjesec);
    Kalendar.obojiZauzeca(kalendar, mjesec, sala, pocetak, kraj);
}

function getOffset(mjesec, dan){
    mjesec +=1;
    var prviDan = new Date(mjesec+"/01/2019 00:00");
    var pomjerenje = (prviDan.getDay() == 0 ? 7: prviDan.getDay());
    dan +=1;
    if(pomjerenje <= dan) return dan-pomjerenje;
    if(pomjerenje > dan && pomjerenje <=7) return 7-pomjerenje+dan;
    return 0;
}

function parseDate(string){
    var regex = /(\d{1,2}.\d{1,2}.\d{4})/;
    var items = string.match(regex);
    let  = new Date(items[2], items[1]-1, items[0]);
    return datum;
}
function dajDan(datum){
    let danSedmice;
    (datum.getDay() == 0) ? danSedmice = 6: danSedmice = datum.getDay()-1;
    return danSedmice;
}
function parseTime(string){
    var regex = /(\d{2}-\d{2})/;
    var items = string.match(regex);
    let datum = new Date(2019,1,1,items[0], items[1]);
    return datum;
}

function odgovarajuciMjesec(datum, mjesec){
    //if(parseInt(datum.substring(3,5)) == mjesec+1) return true;
    if(datum[2] == "."){
        if(datum[5] == ".") if(parseInt(datum.substring(3,5)) == mjesec+1) return true;
        else if(parseInt(datum.substring(3,4)) == mjesec+1) return true;
    }
    else{
        if(datum[4] == ".") if(parseInt(datum.substring(2,4)) == mjesec+1) return true;
        else if(parseInt(datum.substring(2,3)) == mjesec+1) return true;
    }
    return false;
}
function odgovarajuciSemestar(semestar, mjesec){
    if(semestar == "ljetni"){
        if(ljetniSemestar.includes(mjesec)){
            return true;
        }
    }
    if(semestar == "zimski"){
        if(zimskiSemestar.includes(mjesec)){
            return true;
        }
    }
    return false;
}
function ukljucujeTermin(vrijemePocetka, vrijemeKraja, pocetak, kraj){
    var p1 = new Date("01/01/2019 "+pocetak);
    var p2 = new Date("01/01/2019 "+vrijemePocetka);
    var k1 = new Date("01/01/2019 "+kraj);
    var k2 = new Date("01/01/2019 "+vrijemeKraja);
    
    if((p1 >= p2 && k1 <= k2)||(p1 <= p2 && k1 >= k2)){
        return true;
    }
    
    /*if(p1 <= p2 && k1 >= k2){
        return true;
    }*/
    return false;
}

function validanPeriodicniElement(element){
    if(element.dan >=0 && element.dan <7){
        if(element.semestar == "zimski" || element.semestar == "ljetni"){
            if(new Date("01/01/2019 "+element.pocetak) < new Date("01/01/2019 "+element.kraj)){
                return true;
            }
        }
    }
    return false;
}
function validanVanredniElement(element){
    var date = new Date(element.datum.substring(6,10)+"/"+element.datum.substring(3,5)+"/"+element.datum.substring(0,3));
    if(date.getFullYear() == 2019){
        if(new Date("01/01/2019 "+element.pocetak) < new Date("01/01/2019 "+element.kraj)){
            return true;
        }
    }
    return false;
}

function dajBrojTrenutnogMjeseca(kalendar){
    var naziv = kalendar.children[0];
    var mjeseci = [{ime: "Januar", broj : 0}, {ime: "Februar", broj : 1}, {ime: "Mart", broj : 2}, {ime: "April", broj : 3}, {ime: "Maj", broj : 4},
                    {ime: "Juni", broj : 5}, {ime: "Juli", broj : 6}, {ime: "August", broj : 7}, {ime: "Septembar", broj : 8}, {ime: "Oktobar", broj : 9},
                    {ime: "Novembar", broj : 10}, {ime: "Decembar", broj : 11}];
    var i;
    for (i=0; i< mjeseci.length; i++){
        if(naziv.innerHTML.indexOf(mjeseci[i].ime) != -1){
            return mjeseci[i].broj;
        }
    }
}

function dajNazivMjeseca(broj){
    var mjeseci = [{ime: "Januar", broj : 0}, {ime: "Februar", broj : 1}, {ime: "Mart", broj : 2}, {ime: "April", broj : 3}, {ime: "Maj", broj : 4},
                    {ime: "Juni", broj : 5}, {ime: "Juli", broj : 6}, {ime: "August", broj : 7}, {ime: "Septembar", broj : 8}, {ime: "Oktobar", broj : 9},
                    {ime: "Novembar", broj : 10}, {ime: "Decembar", broj : 11}];
    var i;
    for(i = 0; i< mjeseci.length; i++){
        if(mjeseci[i].broj == broj){
            return mjeseci[i].ime+" 2019"
        }
    }
}