var mjesec=10;
var niz1=new Kalendar.periodicna(0, "zimski", "01:00", "01:30", "0-01", "sanida");
var niz2=new Kalendar.periodicna(1, "ljetni", "12:00", "13:30", "0-01", "sanida");
var niz3=new Kalendar.periodicna(2, "zimski", "12:00", "13:30", "1-01", "sanida");
var niz4=new Kalendar.vanredna("10.10.2019", "12:00", "13:30", "1-01", "sanida");
var niz5=new Kalendar.vanredna("11.11.2019", "12:00", "13:30", "1-08", "sanida");
var niz6=new Kalendar.vanredna("11.11.2019", "12:00", "13:30", "1-08", "sanida");
var kalendar1;

var glavniNiz1=[niz1, niz2, niz3];
var glavniNiz2=[niz4, niz5, niz6];
function pokreni() {
	Kalendar.iscrtajKalendar(document.getElementById("kalendar"), mjesec);
	Kalendar.ucitajPodatke(glavniNiz1, glavniNiz2);
}
function pokreni1() {
	if(mjesec>0) {
		mjesec--;
		Kalendar.iscrtajKalendar(document.getElementById("kalendar"), mjesec);
		var trenutnaSala= document.getElementsByName("sale")[0].value;
		var pocetakTrenutni=document.getElementsByName("pocetak")[0].value;
		var krajTrenutni= document.getElementsByName("kraj")[0].value;
		Kalendar.obojiZauzeca(document.getElementById("kalendar"), mjesec, trenutnaSala, pocetakTrenutni, krajTrenutni);
		if(mjesec==0) 
			document.getElementById("dugme1").disabled = true;

		if(mjesec<11)
			document.getElementById("dugme2").disabled = false;
	}
	else {
		document.getElementById("dugme1").disabled = true;
	}
}
function pokreni2(){
	if(mjesec<=11) {
		mjesec++;
		Kalendar.iscrtajKalendar(document.getElementById("kalendar"), mjesec);
		var trenutnaSala= document.getElementsByName("sale")[0].value;
		var pocetakTrenutni=document.getElementsByName("pocetak")[0].value;
		var krajTrenutni= document.getElementsByName("kraj")[0].value;
		Kalendar.obojiZauzeca(document.getElementById("kalendar"), mjesec, trenutnaSala, pocetakTrenutni, krajTrenutni);
		if(mjesec==11) 
			document.getElementById("dugme2").disabled = true;
			
		if(mjesec>0)
			document.getElementById("dugme1").disabled = false;
	}
	else {
		document.getElementById("dugme2").disabled = true;
	}
}
function funkcija1(){
	var trenutnaSala= document.getElementsByName("sale")[0].value;
    var pocetakTrenutni=document.getElementsByName("pocetak")[0].value;
    var krajTrenutni= document.getElementsByName("kraj")[0].value;
    Kalendar.obojiZauzeca(document.getElementById("kalendar"), mjesec, trenutnaSala, pocetakTrenutni, krajTrenutni);
}