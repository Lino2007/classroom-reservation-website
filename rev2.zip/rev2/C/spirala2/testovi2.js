let assert = chai.assert;
describe('Kalendar', function() {
    describe('iscrtajKalendar()', function() {
        //test1 (za april)
        it('mjesec sa 30 dana: ocekivano 30 dana', function() {
            let kalRef = document.getElementById("kalendar");
            Kalendar.iscrtajKalendar(kalRef,3);
            let tabela1=document.getElementsByTagName('table')[0];
            let brojDana=0;
            for(var i=2; i<=7;i++){
                for(var j=0;j<7;j++)
                    if(tabela1.rows[i].cells[j].innerHTML!="")
                        brojDana++;
            }
            assert.equal(brojDana, 30,"Broj dana treba biti 30");
        });
        //test2 (za januar)
        it('mjesec sa 31 dana: ocekivano 31 dana', function() {
            let kalRef = document.getElementById("kalendar");
            Kalendar.iscrtajKalendar(kalRef,0);
            let tabela1=document.getElementsByTagName('table')[0];
            let brojDana=0;
            for(var i=2; i<=7;i++){
                for(var j=0;j<7;j++)
                    if(tabela1.rows[i].cells[j].innerHTML!="")
                        brojDana++;
            }
            assert.equal(brojDana, 31,"Broj dana treba biti 31");
        });
        //test3 (za novembar)
        it('trenutni mjesec: ocekivano prvi dan u petak', function() {
            let kalRef = document.getElementById("kalendar");
            Kalendar.iscrtajKalendar(kalRef,10);
            let tabela1=document.getElementsByTagName('table')[0];
            let dan=0;
            for(var j=0;j<7;j++){
                if(tabela1.rows[2].cells[j].innerHTML!="") break;
                dan++;
            }
            assert.equal(dan, 4,"Prvi dan treba biti petak");
        });
        //test4 (za novembar)
        it('trenutni mjesec: ocekivano 30. dan u subotu', function() {
            let kalRef = document.getElementById("kalendar");
            Kalendar.iscrtajKalendar(kalRef,10);
            let tabela1=document.getElementsByTagName('table')[0];
            //ako je u sub 30
            let dan=tabela1.rows[6].cells[5].innerHTML;
            assert.equal(dan, 30,"Zadnji dan treba biti subota");
        });
        //test6 (za januar)
        it('očekivano je da brojevi dana idu od 1 do 31 počevši od utorka', function() {
            let kalRef = document.getElementById("kalendar");
            Kalendar.iscrtajKalendar(kalRef,0);
            let tabela1=document.getElementsByTagName('table')[0];
            let dan=0;
            for(var j=0;j<7;j++){
                if(tabela1.rows[2].cells[j].innerHTML==="") dan++;;
            }
            let dan1=tabela1.rows[2].cells[dan].innerHTML;
            let dan2;
            for(var i=6;i<=7;i++){
                for(var j=0;j<7;j++){
                    if(tabela1.rows[i].cells[j].innerHTML!="")   
                        dan2=tabela1.rows[i].cells[j].innerHTML;
                }
            }
            assert.equal(dan, 1,"Prvi dan treba biti utorak");
            assert.equal(dan1, 1,"Mjesec treba poceti sa 1");
            assert.equal(dan2, 31,"Mjesec treba zavrsiti sa 31");
        });   
        //test7 (za februar)
        it('očekivano je da mjesec ima 28 dana', function() {
            let kalRef = document.getElementById("kalendar");
            Kalendar.iscrtajKalendar(kalRef,1);
            let tabela1=document.getElementsByTagName('table')[0];
            let dan2;
            for(var i=6;i<=7;i++){
                for(var j=0;j<7;j++){
                    if(tabela1.rows[i].cells[j].innerHTML!="")   
                        dan2=tabela1.rows[i].cells[j].innerHTML;
                }
            }
            assert.equal(dan2, 28,"Mjesec treba zavrsiti sa 28");
        });  
        //test8 (za februar)
        it('očekivano je da mjesec zavrsava u cetvrtak', function() {
            let kalRef = document.getElementById("kalendar");
            Kalendar.iscrtajKalendar(kalRef,1);
            let tabela1=document.getElementsByTagName('table')[0];
            let dan2=0;
            for(var i=6;i<=7;i++){
                dan2=0;
                for(var j=0;j<7;j++){
                    if(tabela1.rows[i].cells[j].innerHTML!="")   
                        dan2++;
                }
                if(tabela1.rows[i].cells[6].innerHTML=="") break;
            }
            assert.equal(dan2, 4,"Mjesec treba zavrsiti u cetvrtak");
        });
        
    });
    describe('obojiZauzeca()', function() {
        //test1 
        it('kada podaci nisu ucitani: da se ne oboji nista', function() {
            let kalRef = document.getElementById("kalendar");
            let tabela1=document.getElementsByTagName('table')[0];
            Kalendar.obojiZauzeca(kalRef,10,"0-01", "11:00", "12:00");
            let tabela2=document.getElementsByTagName('table')[0];
            assert.equal(tabela1, tabela2,"Nista se nije promijenilo u tabeli");
        });
         //test2
         it('kada u zauzecima postoje duple vrijednosti: očekivano obojen taj dan', function() {
            let kalRef = document.getElementById("kalendar");
            let tabela1=document.getElementsByTagName('table')[0];
            let niz1=new Kalendar.periodicna(1, "ljetni", "12:00", "13:30", "0-01", "sanida");
            let niz2=new Kalendar.vanredna("11.11.2019", "12:00", "13:30", "1-08", "sanida");
            let niz3=new Kalendar.vanredna("11.11.2019", "12:00", "13:30", "1-08", "sanida");
            var glavniNiz1=[niz1];
            var glavniNiz2=[niz2, niz3];
            Kalendar.ucitajPodatke(glavniNiz1, glavniNiz2);
            Kalendar.obojiZauzeca(kalRef,10,"1-08", "11:00", "15:00");
            let celija1=tabela1.rows[4].cells[0];
            let boja=celija1.style.borderBottomColor;
            let boja2='red';
            assert.equal(boja, boja2,"Celija ostane obojena");
        });
        //test3
        it('kada u podacima postoji periodično zauzeće za drugi semestar: očekivano je da se ne oboji zauzeće', function() {
            let kalRef = document.getElementById("kalendar");
            let tabela1=document.getElementsByTagName('table')[0];
            let niz1=new Kalendar.periodicna(1, "ljetni", "12:00", "13:30", "1-08", "sanida");
            var glavniNiz1=[niz1];
            var glavniNiz2=[];
            Kalendar.ucitajPodatke(glavniNiz1, glavniNiz2);
            Kalendar.obojiZauzeca(kalRef,10,"1-08", "11:00", "15:00");
            let boja2='green';
            for(var i=2;i<=7;i++){
                for(var j=0;j<7;j++){ 
                    if(tabela1.rows[i].cells[j].innerHTML!=""){
                        let celija1=tabela1.rows[i].cells[j];
                        let boja=celija1.style.borderBottomColor;
                        assert.equal(boja, boja2,"Celije nisu obojene jer je novembar");    
                    }    
                 }
            }
            
        });
        //test4
        it('kada u podacima postoji zauzeće ali u drugom mjesecu: očekivano je da se ne oboji zauzeće', function() {
            let kalRef = document.getElementById("kalendar");
            let tabela1=document.getElementsByTagName('table')[0];
            let niz1=new Kalendar.periodicna(1, "ljetni", "12:00", "13:30", "0-01", "sanida");
            let niz3=new Kalendar.vanredna("11.12.2019", "12:00", "13:30", "1-08", "sanida");
            var glavniNiz1=[niz1];
            var glavniNiz2=[niz3];
            Kalendar.ucitajPodatke(glavniNiz1, glavniNiz2);
            //zauzece je u decembru a na stranici je novembar
            Kalendar.obojiZauzeca(kalRef,10,"1-08", "11:00", "15:00");
            let boja2='green';
            for(var i=2;i<=7;i++){
                for(var j=0;j<7;j++){ 
                    if(tabela1.rows[i].cells[j].innerHTML!=""){
                        let celija1=tabela1.rows[i].cells[j];
                        let boja=celija1.style.borderBottomColor;
                        assert.equal(boja, boja2,"Celije nisu obojene jer je novembar");    
                    }    
                 }
            }
            
        });  
        //test5
        it('kada su u podacima svi termini u mjesecu zauzeti: očekivano je da se svi dani oboje', function() {
            let kalRef = document.getElementById("kalendar");
            let tabela1=document.getElementsByTagName('table')[0];
            let niz1=new Kalendar.periodicna(0, "zimski", "12:00", "13:30", "1-08", "sanida");
            let niz2=new Kalendar.periodicna(1, "zimski", "12:00", "13:30", "1-08", "sanida");
            let niz3=new Kalendar.periodicna(2, "zimski", "12:00", "13:30", "1-08", "sanida");
            let niz4=new Kalendar.periodicna(3, "zimski", "12:00", "13:30", "1-08", "sanida");
            let niz5=new Kalendar.periodicna(4, "zimski", "12:00", "13:30", "1-08", "sanida");
            let niz6=new Kalendar.periodicna(5, "zimski", "12:00", "13:30", "1-08", "sanida");
            let niz7=new Kalendar.periodicna(6, "zimski", "12:00", "13:30", "1-08", "sanida");
            let niz8=new Kalendar.vanredna("11.11.2019", "12:00", "13:30", "1-08", "sanida");
            var glavniNiz1=[niz1, niz2, niz3, niz4, niz5, niz6, niz7];
            var glavniNiz2=[niz8];
            Kalendar.ucitajPodatke(glavniNiz1, glavniNiz2);
            Kalendar.obojiZauzeca(kalRef,10,"1-08", "11:00", "15:00");
            let boja2='red';
            for(var i=2;i<=7;i++){
                for(var j=0;j<7;j++){ 
                    if(tabela1.rows[i].cells[j].innerHTML!=""){
                        let celija1=tabela1.rows[i].cells[j];
                        let boja=celija1.style.borderBottomColor;
                        assert.equal(boja, boja2,"Svi dani su obojeni");    
                    }    
                 }
            }
            
        });
        //test6
        it('dva uzastopna pozivanja oboji zauzece: očekivano da zauzeće ostane iste boje', function() {
            let kalRef = document.getElementById("kalendar");
            let tabela1=document.getElementsByTagName('table')[0];
            let niz1=new Kalendar.periodicna(1, "ljetni", "12:00", "13:30", "0-01", "sanida");
            let niz3=new Kalendar.vanredna("11.11.2019", "12:00", "13:30", "1-08", "sanida");
            var glavniNiz1=[niz1];
            var glavniNiz2=[niz3];
            Kalendar.ucitajPodatke(glavniNiz1, glavniNiz2);
            //prvi poziv
            Kalendar.obojiZauzeca(kalRef,10,"1-08", "11:00", "15:00");
            let boja1=tabela1.rows[4].cells[0].style.borderBottomColor;
            //drugi poziv
            Kalendar.obojiZauzeca(kalRef,10,"1-08", "11:00", "15:00");
            let boja2=tabela1.rows[4].cells[0].style.borderBottomColor;
            assert.equal(boja1, boja2,"Celija je ostala isto obojena");        
            
        });  
        //test7
        it('ucitajPodatke, obojiZauzeca, ucitajPodatke--drugi podaci, obojiZauzeca: ocekivano obojena zauzeca samo iz najnovijih podataka', function() {
            let kalRef = document.getElementById("kalendar");
            let tabela1=document.getElementsByTagName('table')[0];
            let niz1=new Kalendar.periodicna(1, "ljetni", "12:00", "13:30", "0-01", "sanida");
            let niz3=new Kalendar.vanredna("11.11.2019", "12:00", "13:30", "1-08", "sanida");
            var glavniNiz1=[niz1];
            var glavniNiz2=[niz3];
            Kalendar.ucitajPodatke(glavniNiz1, glavniNiz2);
            //prvi poziv oboji
            Kalendar.obojiZauzeca(kalRef,10,"1-08", "11:00", "15:00");
            //novi podaci--promjena samo npr u vanrednom zauzecu
            let niz2=new Kalendar.vanredna("12.11.2019", "12:00", "13:30", "1-08", "sanida");
            glavniNiz2=[niz2];
            //drugi poziv ucitaj i oboji
            Kalendar.ucitajPodatke(glavniNiz1, glavniNiz2);
            Kalendar.obojiZauzeca(kalRef,10,"1-08", "11:00", "15:00");

            let boja1=tabela1.rows[4].cells[0].style.borderBottomColor;
            let boja2=tabela1.rows[4].cells[1].style.borderBottomColor;
            assert.equal(boja1, 'green',"podaci su se updatovali"); 
            assert.equal(boja2, 'red');        
            
        });
        //test8--po izboru (npr. u formi vrijeme 12:00-16:30, a sala sauzeta od 12:00-14:00)
        it('preklapanje vremena pocetka unesenog u formi sa ucitanim podacima: ocekivano da se zauzece oboji', function() {
            let kalRef = document.getElementById("kalendar");
            let tabela1=document.getElementsByTagName('table')[0];
            let niz1=new Kalendar.periodicna(1, "ljetni", "12:00", "13:30", "0-01", "sanida");
            let niz3=new Kalendar.vanredna("11.11.2019", "12:00", "13:30", "1-08", "sanida");
            var glavniNiz1=[niz1];
            var glavniNiz2=[niz3];
            Kalendar.ucitajPodatke(glavniNiz1, glavniNiz2);
            Kalendar.obojiZauzeca(kalRef,10,"1-08", "12:00", "16:30");

            let boja1=tabela1.rows[4].cells[0].style.borderBottomColor;
            assert.equal(boja1, 'red',"celija je obojena"); 
                
            
        }); 
        //test9--po izboru 
        it('preklapanje vanrednog zauzeca sa periodicnim: ocekivano da se zauzece oboji', function() {
            let kalRef = document.getElementById("kalendar");
            let tabela1=document.getElementsByTagName('table')[0];
            let niz1=new Kalendar.periodicna(0, "zimski", "12:00", "13:30", "1-08", "sanida");
            let niz3=new Kalendar.vanredna("11.11.2019", "12:00", "13:30", "1-08", "sanida");
            var glavniNiz1=[niz1];
            var glavniNiz2=[niz3];
            Kalendar.ucitajPodatke(glavniNiz1, glavniNiz2);
            Kalendar.obojiZauzeca(kalRef,10,"1-08", "12:00", "16:30");

            let boja1=tabela1.rows[4].cells[0].style.borderBottomColor;
            assert.equal(boja1, 'red',"celija je obojena"); 
                
            
        }); 
        
    });
});
