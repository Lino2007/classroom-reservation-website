window.onload = function(){
    Pozivi.brojPosjetilaca();
    Pozivi.brojRazlicitihIPAdresa();
}