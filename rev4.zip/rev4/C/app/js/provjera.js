const path = require('path');
const glavnaPutanja = path.join(__dirname, '../../');
var lokacija = path.join(glavnaPutanja + '/public/css/pocetna.css');
console.log(lokacija);