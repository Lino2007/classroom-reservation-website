const express = require("express");
const app = express();
const bodyParser = require('body-parser');
const fs = require("fs");
var path = require("path");
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

app.use(express.static("public"));

const Sequelize = require('sequelize');
const sequelize = require('./baza/db.js');
const db = require('./baza/db.js');

app.get('/', function (req, res) {
    res.sendFile(path.join(__dirname + '/pocetna.html'))
});

app.get('/', function (req, res) {
    res.sendFile(path.join(__dirname + '/sale.html'))
});

app.get('/', function (req, res) {
    res.sendFile(path.join(__dirname + '/unos.html'))
});

app.get('/', function (req, res) {
    res.sendFile(path.join(__dirname + '/rezervacija.html'))
});

app.get('/', function (req, res) {
    res.sendFile(path.join(__dirname + '/osobe.html'))
});

app.get('/oznaciSlike', function (req, res) {
    fs.readFile('slike.json', (err, data) => {
        if (err) throw err;
        let slike = JSON.parse(data);
        for (let i = 0; i < slike.length; i++) slike[i].ucitana = "false";
        fs.writeFile('slike.json', JSON.stringify(slike), 'utf-8', function (err) {
            if (err) throw err
        });
    });
})

app.get('/slike', function (req, res) {
    fs.readFile('slike.json', (err, data) => {
        if (err) throw err;
        let slike = JSON.parse(data);
        let ucSlike = new Array();
        for (let i = 0; i < slike.length; i++) {
            if (slike[i].ucitana === "false") {
                let slika = new Object();
                slika.id = (i + 1).toString();
                slika.src = slike[i].src;
                ucSlike.push(slika);
                slike[i].ucitana = "true";
            }
            if (ucSlike.length === 3) break;
        }
        fs.writeFile('slike.json', JSON.stringify(slike), 'utf-8', function (err) {
            if (err) throw err
            res.send(JSON.stringify(ucSlike));
        });
    });
})


function vanrednoP(datum, pocetak, kraj, naziv, predavac) {
    let van = new Object();
    let dd = datum.getDate().toString();
    let mm = (datum.getMonth() + 1).toString();
    let yyyy = datum.getFullYear().toString();
    if (dd < 10 && dd.length === 1) dd = "0" + dd;
    if (mm < 10 && mm.length === 1) mm = "0" + mm;
    van.datum = dd + "." + mm + "." + yyyy;
    van.pocetak = pocetak;
    van.kraj = kraj;
    van.naziv = naziv;
    van.predavac = predavac;
    return van;
}


function PretvoriUVanredna(periodicna) {
    let vanOdPer = new Array();
    let trenutniDatum = new Date();
    let trenutnaGodina = trenutniDatum.getFullYear();
    //za svako periodicno zauzece
    for (let i = 0; i < periodicna.length; i++) {
        let per = periodicna[i];
        //semestar zimski (jan, okt, nov, dec)
        if (per.semestar === "zimski") {
            let prviJanuar = new Date(trenutnaGodina, 0, 1);
            let zadnjiJanuar = new Date(trenutnaGodina, 1, 0);
            let prviOktobar = new Date(trenutnaGodina, 9, 1);
            let zadnjiOktobar = new Date(trenutnaGodina, 10, 0);
            let prviNovembar = new Date(trenutnaGodina, 10, 1);
            let zadnjiNovembar = new Date(trenutnaGodina, 11, 0);
            let prviDecembar = new Date(trenutnaGodina, 11, 1);
            let zadnjiDecembar = new Date(trenutnaGodina, 12, 0);

            //za januar
            for (let i = prviJanuar.getDate(); i <= zadnjiJanuar.getDate(); i++) {
                if (prviJanuar.getDay().toString() === per.dan) {
                    let dat = new Date(prviJanuar);
                    let van = vanrednoP(dat, per.pocetak, per.kraj, per.naziv, per.predavac);
                    vanOdPer.push(van);
                }
                prviJanuar.setDate(prviJanuar.getDate() + 1);
            }

            //za oktobar
            for (let i = prviOktobar.getDate(); i <= zadnjiOktobar.getDate(); i++) {
                if (prviOktobar.getDay().toString() === per.dan) {
                    let dat = new Date(prviOktobar);
                    let van = vanrednoP(dat, per.pocetak, per.kraj, per.naziv, per.predavac);
                    vanOdPer.push(van);
                }
                prviOktobar.setDate(prviOktobar.getDate() + 1);
            }

            //za novembar
            for (let i = prviNovembar.getDate(); i <= zadnjiNovembar.getDate(); i++) {
                if (prviNovembar.getDay().toString() === per.dan) {
                    let dat = new Date(prviNovembar);
                    let van = vanrednoP(dat, per.pocetak, per.kraj, per.naziv, per.predavac);
                    vanOdPer.push(van);
                }
                prviNovembar.setDate(prviNovembar.getDate() + 1);
            }

            //za decembar
            for (let i = prviDecembar.getDate(); i <= zadnjiDecembar.getDate(); i++) {
                if (prviDecembar.getDay().toString() === per.dan) {
                    let dat = new Date(prviDecembar);
                    let van = vanrednoP(dat, per.pocetak, per.kraj, per.naziv, per.predavac);
                    vanOdPer.push(van);
                }
                prviDecembar.setDate(prviDecembar.getDate() + 1);
            }
        }
        else if (per.semestar === "ljetni") {
            let prviFebruar = new Date(trenutnaGodina, 1, 1);
            let zadnjiFebruar = new Date(trenutnaGodina, 2, 0);
            let prviMart = new Date(trenutnaGodina, 2, 1);
            let zadnjiMart = new Date(trenutnaGodina, 3, 0);
            let prviApril = new Date(trenutnaGodina, 3, 1);
            let zadnjiApril = new Date(trenutnaGodina, 4, 0);
            let prviMaj = new Date(trenutnaGodina, 4, 1);
            let zadnjiMaj = new Date(trenutnaGodina, 5, 0);
            let prviJuni = new Date(trenutnaGodina, 5, 1);
            let zadnjiJuni = new Date(trenutnaGodina, 6, 0);

            //za februar
            for (let i = prviFebruar.getDate(); i <= zadnjiFebruar.getDate(); i++) {
                if (prviFebruar.getDay().toString() === per.dan) {
                    let dat = new Date(prviFebruar);
                    let van = vanrednoP(dat, per.pocetak, per.kraj, per.naziv, per.predavac);
                    vanOdPer.push(van);
                }
                prviFebruar.setDate(prviFebruar.getDate() + 1);
            }

            //za mart
            for (let i = prviMart.getDate(); i <= zadnjiMart.getDate(); i++) {
                if (prviMart.getDay().toString() === per.dan) {
                    let dat = new Date(prviMart);
                    let van = vanrednoP(dat, per.pocetak, per.kraj, per.naziv, per.predavac);
                    vanOdPer.push(van);
                }
                prviMart.setDate(prviMart.getDate() + 1);
            }

            //za april
            for (let i = prviApril.getDate(); i <= zadnjiApril.getDate(); i++) {
                if (prviApril.getDay().toString() === per.dan) {
                    let dat = new Date(prviApril);
                    let van = vanrednoP(dat, per.pocetak, per.kraj, per.naziv, per.predavac);
                    vanOdPer.push(van);
                }
                prviApril.setDate(prviApril.getDate() + 1);
            }

            //za maj
            for (let i = prviMaj.getDate(); i <= zadnjiMaj.getDate(); i++) {
                if (prviMaj.getDay().toString() === per.dan) {
                    let dat = new Date(prviMaj);
                    let van = vanrednoP(dat, per.pocetak, per.kraj, per.naziv, per.predavac);
                    vanOdPer.push(van);
                }
                prviMaj.setDate(prviMaj.getDate() + 1);
            }

            //za juni
            for (let i = prviJuni.getDate(); i <= zadnjiJuni.getDate(); i++) {
                if (prviJuni.getDay().toString() === per.dan) {
                    let dat = new Date(prviJuni);
                    let van = vanrednoP(dat, per.pocetak, per.kraj, per.naziv, per.predavac);
                    vanOdPer.push(van);
                }
                prviJuni.setDate(prviJuni.getDate() + 1);
            }
        }
    }
    return vanOdPer;
}


function USekunde(vrijeme) {
    let a = vrijeme.split(":");
    let seconds = a[0] * 60 * 60 + a[1] * 60;
    return seconds;
}

//Spirala 4
/*

//Inicijalizacija baze
db.sequelize.sync({ force: true }).then(function () {
    inicijalizacija().then(function () {
        console.log("Gotovo kreiranje tabela i ubacivanje pocetnih podataka!");
    });
});

function inicijalizacija() {
    let osobljeListaPromisea = [];
    let saleListaPromisea = [];
    let terminiListaPromisea = [];
    let rezervacijeListaPromisea = [];
    return new Promise(function (resolve, reject) {
        osobljeListaPromisea.push(db.osoblje.create({ ime: 'Neko', prezime: 'Nekić', uloga: 'profesor' }));
        osobljeListaPromisea.push(db.osoblje.create({ ime: 'Drugi', prezime: 'Neko', uloga: 'asistent' }));
        osobljeListaPromisea.push(db.osoblje.create({ ime: 'Test', prezime: 'Test', uloga: 'asistent' }));

        Promise.all(osobljeListaPromisea).then(function (osoblje) {
            let neko = osoblje.filter(function (a) { return a.ime === 'Neko' && a.prezime === 'Nekić' && a.uloga === 'profesor' })[0];
            let drugi = osoblje.filter(function (a) { return a.ime === 'Drugi' && a.prezime === 'Neko' && a.uloga === 'asistent' })[0];
            let test = osoblje.filter(function (a) { return a.ime === 'Test' && a.prezime === 'Test' && a.uloga === 'asistent' })[0];

            //Ovo promijenjeno - nakon sto je kreirana prva sala - 1-11, onda kreiraj drugu salu - 1-15
            saleListaPromisea.push(db.sala.create({ naziv: '1-11', zaduzenaOsoba: neko.id }).then(function (s) {
                saleListaPromisea.push(db.sala.create({ naziv: '1-15', zaduzenaOsoba: drugi.id }));
                return new Promise(function (resolve, reject) { resolve(s); });
            }));

            Promise.all(saleListaPromisea).then(function (sale) {
                let sala1_11 = sale.filter(function (a) { return a.naziv === '1-11' && a.zaduzenaOsoba === 1 })[0];
                let sala1_15 = sale.filter(function (a) { return a.naziv === '1-15' && a.zaduzenaOsoba === 2 })[0];

                terminiListaPromisea.push(db.termin.create({ redovni: false, dan: null, datum: '01.01.2020', semestar: null, pocetak: '12:00', kraj: '13:00' }));
                terminiListaPromisea.push(db.termin.create({ redovni: true, dan: 0, datum: null, semestar: 'zimski', pocetak: '13:00', kraj: '14:00' }));

                Promise.all(terminiListaPromisea).then(function (termini) {
                    let termin1 = termini.filter(function (a) { return a.redovni === false && a.dan === null && a.datum === '01.01.2020' && a.semestar === null && a.pocetak === '12:00' && a.kraj === '13:00' })[0];
                    let termin2 = termini.filter(function (a) { return a.redovni === true && a.dan === 0 && a.datum === null && a.semestar === 'zimski' && a.pocetak === '13:00' && a.kraj === '14:00' })[0];

                    rezervacijeListaPromisea.push(db.rezervacija.create({ termin: termin1.id, sala: sala1_11.id, osoba: neko.id }));
                    rezervacijeListaPromisea.push(db.rezervacija.create({ termin: termin2.id, sala: sala1_11.id, osoba: test.id }));

                    Promise.all(rezervacijeListaPromisea).then(function (b) { resolve(b); }).catch(function (err) { console.log("Rezervacije greska " + err); });
                }).catch(function (err) { console.log("Termini greska (pri inicijalizaciji): " + err); });
            }).catch(function (err) { console.log("Sale greska (pri inicijalizaciji): " + err); });
        }).catch(function (err) { console.log("Osoblje greska (pri inicijalizaciji): " + err); });
    })
}
*/
//Zadatak 1
//Dohvatanje svih osoba
app.get('/osoblje', function (req, res) {
    db.osoblje.findAll({
        attributes: ['id', 'ime', 'prezime', 'uloga']
    }).then(function (osoblje) {
        res.send(osoblje);
    });
})
//Dohvatanje svih sala
app.get('/sale', function (req, res) {
    db.sala.findAll({
        attributes: ['id', 'naziv', 'zaduzenaOsoba']
    }).then(function (sale) {
        res.send(sale);
    });
})

//Zadatak 3.
app.get('/zauzeca', function (req, res) {
    let danas = kreirajObjekatDanas();
    let result = []; //rezultat koji saljemo sa servera 
    let terminiPreklapanje = [];
    //Pronalazimo sve termine koji se preklapaju sa trenutnim vremenom i datumom/danom
    db.termin.findAll().then(function (termini) {
        termini.forEach(t => {
            if (((t.redovni === false && t.datum === danas.datum) ||
                (t.redovni === true && t.dan === danas.dan && t.semestar === danas.semestar))
                && danas.vrijeme >= t.pocetak && danas.vrijeme <= t.kraj) {
                terminiPreklapanje.push(t.getRezervacijaTermin());
            }
        });

        Promise.all(terminiPreklapanje).then(function (r) {
            db.osoblje.findAll().then(function (osobe) {
                db.sala.findAll().then(function (sale) {
                    let razlicito = "";
                    //Prolazimo kroz sve osobe
                    for (let i = 0; i < osobe.length; i++) {
                        razlicito = true;
                        //Prolazimo kroz sve rezervacije koje imaju preklapanje sa trenutnim vremenom i datumom/danom
                        for (let j = 0; j < r.length; j++) {
                            //Ako smo nasli osobu kojoj pripada rezervacija sa preklapanjem
                            if (osobe[i].id === r[j].osoba) {
                                let sala = sale.filter(function (a) { return a.id === r[j].sala })[0];
                                result.push({ imeOsobe: osobe[i].ime + " " + osobe[i].prezime, osobaSala: sala.naziv });
                                razlicito = false;
                                break;
                            }
                        }
                        //Ako nismo pronasli osobu kojoj pripada rezervacija sa preklapanjem
                        if (razlicito) result.push({ imeOsobe: osobe[i].ime + " " + osobe[i].prezime, osobaSala: "u kancelariji" });
                    }
                    res.send(result);
                })
            })
        })
    })
})

//Pomocna funkcija koja kreira objekat danas, koji posjeduje datum, dan, vrijeme i semestar
function kreirajObjekatDanas() {
    let danas = new Object();
    let danasnjiDatum = new Date();

    let d = danasnjiDatum.getDate().toString();
    if (d < 10 && d.length === 1) d = "0" + d;

    let m = (danasnjiDatum.getMonth() + 1).toString();
    if (m < 10 && m.length === 1) m = "0" + m;

    let semestar = "";
    if (m === "01" || m === "10" || m === "11" || m === "12") semestar += "zimski";
    else if (m === "02" || m === "03" || m === "04" || m === "05" || m === "06") semestar += "ljetni";

    let sati = danasnjiDatum.getHours().toString();
    if (sati < 10 && sati.length === 1) sati = "0" + sati;

    let minute = danasnjiDatum.getMinutes().toString();
    if (minute < 10 && minute.length === 1) minute = "0" + minute;

    let dan = danasnjiDatum.getDay(); //danasnji dan 
    let datum = d + "." + m + "." + danasnjiDatum.getFullYear().toString(); //danasnji datum
    let vrijeme = sati + ":" + minute; //trenutno vrijeme

    danas.datum = datum;
    danas.dan = dan;
    danas.vrijeme = vrijeme;
    danas.semestar = semestar;
    return danas;
}

//Zadatak 2.
//Ucitavanje podataka iz baze - ruta za dohvatanje svih rezervacija
app.get('/ucitajIzBaze', function (req, res) {
    let zauzeca = new Object(); //rezultat koji saljemo sa servera 
    zauzeca.periodicna = [];
    zauzeca.vanredna = [];
    db.termin.findAndCountAll().then(function (t) {
        let redovi_result = t.rows;
        //Prolazimo kroz sve termine
        for (let i = 0; i < redovi_result.length; i++) {
            let termin = redovi_result[i];
            //Uzimamo rezervaciju termina
            termin.getRezervacijaTermin().then(function (r) {
                //Pronalazimo osobu cija je rezervacija
                r.getOsobaRezervacija().then(function (osoba) {
                    //Pronalazimo salu rezervacije
                    r.getSalaRezervacija().then(function (sala) {
                        //Ako je zauzece periodicno
                        if (termin.redovni)
                            zauzeca.periodicna.push(
                                {
                                    dan: termin.dan.toString(),
                                    semestar: termin.semestar,
                                    pocetak: termin.pocetak.substr(0, termin.pocetak.length - 3),
                                    kraj: termin.kraj.substr(0, termin.kraj.length - 3),
                                    naziv: sala.naziv,
                                    predavac: osoba.ime + " " + osoba.prezime
                                }
                            );
                        //Ako je zauzece vanredno
                        else
                            zauzeca.vanredna.push(
                                {
                                    datum: termin.datum,
                                    pocetak: termin.pocetak.substr(0, termin.pocetak.length - 3),
                                    kraj: termin.kraj.substr(0, termin.kraj.length - 3),
                                    naziv: sala.naziv,
                                    predavac: osoba.ime + " " + osoba.prezime
                                }
                            );
                        //Ako smo uzeli sve termine, vrati zauzeca
                        if (redovi_result.length === zauzeca.vanredna.length + zauzeca.periodicna.length)
                            res.send(zauzeca);
                    })
                })
            })
        }
    })
})

//Ruta za upisivanje vanrednog zauzeca u bazu
app.post('/upisiVanrednoZauzeceUBazu', function (req, res) {
    let tijelo = req.body;
    let van1 = tijelo.vanrednoZauzece;

    //Odredjujemo dan i  semestar vanrednog zauzeca
    let d = van1.datum.substr(0, 2);
    let m = van1.datum.substr(3, 2);
    let y = van1.datum.substr(6, van1.datum.length - 1);
    let datum = new Date(y + "-" + m + "-" + d);
    let dan = datum.getDay();
    let semestar = "";
    if (m === "01" || m === "10" || m === "11" || m === "12") semestar += "zimski";
    else if (m === "02" || m === "03" || m === "04" || m === "05" || m === "06") semestar += "ljetni";
    else semestar = null;

    let imeOsoba = van1.predavac.split(' ').slice(0, -1).join(' '); //Pazimo u slucaju osoba sa dva imena
    let prezimeOsoba = van1.predavac.split(' ').slice(-1).join(' ');

    let zauzeca = tijelo.zauzeca;
    let vanOdper = PretvoriUVanredna(zauzeca.periodicna); //niz vanrednih zauzeca koja su periodicna

    let razlicita1;
    let razlicita2;

    for (let i = 0; i < zauzeca.vanredna.length; i++) {
        razlicita1 = true;
        if (zauzeca.vanredna[i].datum === van1.datum &&
            zauzeca.vanredna[i].naziv === van1.naziv &&
            ((USekunde(van1.pocetak) >= USekunde(zauzeca.vanredna[i].pocetak) &&
                USekunde(van1.pocetak) < USekunde(zauzeca.vanredna[i].kraj)) ||
                (USekunde(van1.kraj) > USekunde(zauzeca.vanredna[i].pocetak) &&
                    USekunde(van1.kraj) <= USekunde(zauzeca.vanredna[i].kraj)) ||
                (USekunde(van1.pocetak) < USekunde(zauzeca.vanredna[i].pocetak) &&
                    USekunde(van1.kraj) > USekunde(zauzeca.vanredna[i].kraj)))
        ) {
            razlicita1 = false;
            break;
        }
    }

    for (let i = 0; i < vanOdper.length; i++) {
        razlicita2 = true;
        if (vanOdper[i].datum === van1.datum &&
            vanOdper[i].naziv === van1.naziv &&
            ((USekunde(van1.pocetak) >= USekunde(vanOdper[i].pocetak) &&
                USekunde(van1.pocetak) < USekunde(vanOdper[i].kraj)) ||
                (USekunde(van1.kraj) > USekunde(vanOdper[i].pocetak) &&
                    USekunde(van1.kraj) <= USekunde(vanOdper[i].kraj)) ||
                (USekunde(van1.pocetak) < USekunde(vanOdper[i].pocetak) &&
                    USekunde(van1.kraj) > USekunde(vanOdper[i].kraj)))
        ) {
            razlicita2 = false;
            break;
        }
    }
    //Ako ne postoji preklapanje zauzeca, ubacujemo novu vanrednu rezervaciju u bazu
    if (razlicita1 && razlicita2) {
        zauzeca.vanredna.push(van1); //ubacujemo novo vanredno zauzece u niz zauzeca

        let osobljeListaPromisea = [];
        let saleListaPromisea = [];
        let terminiListaPromisea = [];
        let rezervacijeListaPromisea = [];
        return new Promise(function (resolve, reject) {
            osobljeListaPromisea.push(db.osoblje.findOne({ where: { ime: imeOsoba, prezime: prezimeOsoba } }));

            Promise.all(osobljeListaPromisea).then(function (osoblje) {
                let osoba = osoblje.filter(function (a) { return a.ime === imeOsoba && a.prezime === prezimeOsoba })[0];

                saleListaPromisea.push(db.sala.findOne({ where: { naziv: van1.naziv } }));

                Promise.all(saleListaPromisea).then(function (sale) {
                    let sala = sale.filter(function (a) { return a.naziv === van1.naziv })[0];

                    terminiListaPromisea.push(db.termin.create({
                        redovni: false,
                        dan: null,
                        datum: van1.datum,
                        semestar: null,
                        pocetak: van1.pocetak,
                        kraj: van1.kraj
                    }
                    ));

                    Promise.all(terminiListaPromisea).then(function (termini) {
                        let termin = termini.filter(function (a) {
                            return a.redovni === false &&
                                a.dan === null &&
                                a.datum === van1.datum &&
                                a.semestar === null &&
                                a.pocetak === van1.pocetak &&
                                a.kraj === van1.kraj
                        })[0];

                        rezervacijeListaPromisea.push(db.rezervacija.create({
                            termin: termin.id,
                            sala: sala.id,
                            osoba: osoba.id
                        }));

                        Promise.all(rezervacijeListaPromisea).then(function (b) {
                            resolve(b);
                            res.setHeader('Content-Type', 'application/json');
                            res.send(zauzeca); //vracamo zauzeca zajedno sa novododanim zauzecem
                        }).catch(function (err) { console.log("Rezervacije greska (pri ubacivanju vanrednog zazuzeca): " + err); });
                    }).catch(function (err) { console.log("Termini greska (pri ubacivanju vanrednog zazuzeca): " + err); });
                }).catch(function (err) { console.log("Sale greska (pri ubacivanju vanrednog zazuzeca): " + err); });
            }).catch(function (err) { console.log("Osoblje greska (p                                                ri ubacivanju vanrednog zazuzeca): " + err); });
        })
    }                           
    //Ako postoji preklapanje zauzeca, onda je potrebno naci osobu koja je vec ranije rezervisala salu!
    else {
        //Prolazimo kroz sve termine
        db.termin.findAll().then(function (termini) {
            //Trazimo termin koji se preklapa sa novim zauzecem koje se pokusava dodati
            termini.forEach(t                                                                                 => {
                if (((t.redovni === false && t.dan === null
                    && t.datum === van1.datum && t.semestar === null) || (t.redovni === true && t.dan === dan
                        && t.datum === null && t.semestar === semestar)) &&
                    ((USekunde(van1.pocetak) >= USekunde(t.pocetak.substr(0, t.pocetak.length - 3)) &&
                        USekunde(van1.pocetak) < USekunde(t.kraj.substr(0, t.kraj.length - 3))) ||
                        (USekunde(van1.kraj) > USekunde(t.pocetak.substr(0, t.pocetak.length - 3)) &&
                            USekunde(van1.kraj) <= USekunde(t.kraj.substr(0, t.kraj.length - 3))) ||
                        (USekunde(van1.pocetak) < USekunde(t.pocetak.substr(0, t.pocetak.length - 3)) &&
                            USekunde(van1.kraj) > USekunde(t.kraj.substr(0, t.kraj.length - 3))))
                ) {
                    //Kada nadjemo odgovarajuci termin, onda trazimo osobu koja je rezervisala tu salu
                    t.getRezervacijaTermin().then(function (r) {
                        r.getSalaRezervacija().then(function (s) {
                            r.getOsobaRezervacija().then(function (o) {
                                let dat = van1.datum.replace(/[.]/g, "/");
                                res.setHeader('Content-Type', 'text/plain');
                                //Vracamo poruku o sali, vremenu, datumu i osobi koja je vec rezervisala tu salu
                                res.send("Nije moguće rezervisati salu " + van1.naziv + " za navedeni datum " + dat +
                                    " i termin od " + van1.pocetak + " do " + van1.kraj +
                                    "! U ovom terminu salu je već rezervisao " + o.uloga + " " + o.ime + " " + o.prezime + ".");
                            })
                        })
                    })
                }
            });
        })
    }
})

//Ruta za upisivanje periodicnog zauzeca u bazu
app.post('/upisiPeriodicnoZauzeceUBazu', function (req, res) {
    let tijelo = req.body;
    let per1 = tijelo.periodicnoZauzece;
    per1.dan = per1.dan.toString();

    let per1Arr = new Array();
    per1Arr.push(per1);

    let imeOsoba = per1.predavac.split(' ').slice(0, -1).join(' '); //Pazimo u slucaju osoba sa dva imena
    let prezimeOsoba = per1.predavac.split(' ').slice(-1).join(' ');

    let zauzeca = tijelo.zauzeca;

    let kliknutiDatum = tijelo.datum;

    let vanOdper = PretvoriUVanredna(zauzeca.periodicna); //niz vanrednih zauzeca koja su periodicna
    let vanOdper1 = PretvoriUVanredna(per1Arr);

    let razlicita1;
    let razlicita2;

    for (let j = 0; j < vanOdper1.length; j++) {
        razlicita1 = true;
        for (let i = 0; i < zauzeca.vanredna.length; i++) {
            if (zauzeca.vanredna[i].datum === vanOdper1[j].datum &&
                zauzeca.vanredna[i].naziv === vanOdper1[j].naziv &&
                ((USekunde(vanOdper1[j].pocetak) >= USekunde(zauzeca.vanredna[i].pocetak) &&
                    USekunde(vanOdper1[j].pocetak) < USekunde(zauzeca.vanredna[i].kraj)) ||
                    (USekunde(vanOdper1[j].kraj) > USekunde(zauzeca.vanredna[i].pocetak) &&
                        USekunde(vanOdper1[j].kraj) <= USekunde(zauzeca.vanredna[i].kraj)) ||
                    (USekunde(vanOdper1[j].pocetak) < USekunde(zauzeca.vanredna[i].pocetak) &&
                        USekunde(vanOdper1[j].kraj) > USekunde(zauzeca.vanredna[i].kraj)))
            ) {
                razlicita1 = false;
                break;
            }
        }
        if (razlicita1 === false) break;
    }
    for (let j = 0; j < vanOdper1.length; j++) {
        razlicita2 = true;
        for (let i = 0; i < vanOdper.length; i++) {
            if (vanOdper[i].datum === vanOdper1[j].datum &&
                vanOdper[i].naziv === vanOdper1[j].naziv &&
                ((USekunde(vanOdper1[j].pocetak) >= USekunde(vanOdper[i].pocetak) &&
                    USekunde(vanOdper1[j].pocetak) < USekunde(vanOdper[i].kraj)) ||
                    (USekunde(vanOdper1[j].kraj) > USekunde(vanOdper[i].pocetak) &&
                        USekunde(vanOdper1[j].kraj) <= USekunde(vanOdper[i].kraj)) ||
                    (USekunde(vanOdper1[j].pocetak) < USekunde(vanOdper[i].pocetak) &&
                        USekunde(vanOdper1[j].kraj) > USekunde(vanOdper[i].kraj)))
            ) {
                razlicita2 = false;
                break;
            }
        }
        if (razlicita2 === false) break;

    }
    //Ako ne postoji preklapanje zauzeca, ubacujemo novu periodicnu rezervaciju u bazu
    if (razlicita1 && razlicita2) {
        zauzeca.periodicna.push(per1); //ubacujemo novo periodicno zauzece u niz zauzeca

        let osobljeListaPromisea = [];
        let saleListaPromisea = [];
        let terminiListaPromisea = [];
        let rezervacijeListaPromisea = [];
        return new Promise(function (resolve, reject) {
            osobljeListaPromisea.push(db.osoblje.findOne({ where: { ime: imeOsoba, prezime: prezimeOsoba } }));

            Promise.all(osobljeListaPromisea).then(function (osoblje) {
                let osoba = osoblje.filter(function (a) { return a.ime === imeOsoba && a.prezime === prezimeOsoba })[0];

                saleListaPromisea.push(db.sala.findOne({ where: { naziv: per1.naziv } }));

                Promise.all(saleListaPromisea).then(function (sale) {
                    let sala = sale.filter(function (a) { return a.naziv === per1.naziv })[0];

                    terminiListaPromisea.push(db.termin.create({ redovni: true, dan: parseInt(per1.dan), datum: null, semestar: per1.semestar, pocetak: per1.pocetak, kraj: per1.kraj }));

                    Promise.all(terminiListaPromisea).then(function (termini) {
                        let termin = termini.filter(function (a) { return a.redovni === true && a.dan === parseInt(per1.dan) && a.datum === null && a.semestar === per1.semestar && a.pocetak === per1.pocetak && a.kraj === per1.kraj })[0];

                        rezervacijeListaPromisea.push(db.rezervacija.create({ termin: termin.id, sala: sala.id, osoba: osoba.id }));

                        Promise.all(rezervacijeListaPromisea).then(function (b) {
                            resolve(b);
                            res.setHeader('Content-Type', 'application/json');
                            res.send(zauzeca); //vracamo zauzeca zajedno sa novododanim zauzecem
                        }).catch(function (err) { console.log("Rezervacije greska (pri ubacivanju periodicnog zazuzeca): " + err); });
                    }).catch(function (err) { console.log("Termini greska (pri ubacivanju periodicnog zazuzeca): " + err); });
                }).catch(function (err) { console.log("Sale greska (pri ubacivanju periodicnog zazuzeca): " + err); });
            }).catch(function (err) { console.log("Osoblje greska (pri ubacivanju periodicnog zazuzeca): " + err); });
        })
    }
    //Ako je mjesec juli, august ili septembar
    else if (razlicita1 === undefined && razlicita2 === undefined) {
        let mm = kliknutiDatum.substring(3, 5);
        if (mm === "07" || mm === "08" || mm === "09") {
            let mj = "";
            if (mm === "07") mj = "Julu";
            else if (mm === "08") mj = "Augustu";
            else if (mm === "09") mj = "Septembru";
            res.setHeader('Content-Type', 'text/plain');
            res.send("Greška! Nije moguće rezervisati periodično zauzeće u mjesecu " + mj + "!");
        }
    }
    //Ako postoji preklapanje zauzeca, onda je potrebno naci osobu koja je vec ranije rezervisala salu!
    else {
        //Prolazimo kroz sve termine
        db.termin.findAll().then(function (termini) {
            //Trazimo termin koji se preklapa sa novim zauzecem koje se pokusava dodati
            termini.forEach(t => {
                let d = "";
                let m = "";
                let y = "";
                let datum = "";
                let dan = ""; //dan vanrednog termina
                let semestar = ""; //semestar vanrednog termina
                //Ako je termin vanredni, odredjujemo dan i semestar vanrednog termina
                if (t.redovni === false) {
                    d = t.datum.substr(0, 2);
                    m = t.datum.substr(3, 2);
                    y = t.datum.substr(6, t.datum.length - 1);
                    datum = new Date(y + "-" + m + "-" + d);
                    dan = datum.getDay();
                    if (m === "01" || m === "10" || m === "11" || m === "12") semestar += "zimski";
                    else if (m === "02" || m === "03" || m === "04" || m === "05" || m === "06") semestar += "ljetni";
                    else semestar = null;
                }
                if (((t.redovni === true && t.dan.toString() === per1.dan
                    && t.datum === null && t.semestar === per1.semestar) || (t.redovni === false && dan.toString() === per1.dan
                        && semestar === per1.semestar)) &&
                    ((USekunde(per1.pocetak) >= USekunde(t.pocetak.substr(0, t.pocetak.length - 3)) &&
                        USekunde(per1.pocetak) < USekunde(t.kraj.substr(0, t.kraj.length - 3))) ||
                        (USekunde(per1.kraj) > USekunde(t.pocetak.substr(0, t.pocetak.length - 3)) &&
                            USekunde(per1.kraj) <= USekunde(t.kraj.substr(0, t.kraj.length - 3))) ||
                        (USekunde(per1.pocetak) < USekunde(t.pocetak.substr(0, t.pocetak.length - 3)) &&
                            USekunde(per1.kraj) > USekunde(t.kraj.substr(0, t.kraj.length - 3))))
                ) {
                    //Kada nadjemo odgovarajuci termin, onda trazimo osobu koja je rezervisala tu salu
                    t.getRezervacijaTermin().then(function (r) {
                        r.getSalaRezervacija().then(function (s) {
                            r.getOsobaRezervacija().then(function (o) {
                                let dat = kliknutiDatum.replace(/[.]/g, "/");
                                res.setHeader('Content-Type', 'text/plain');
                                res.send("Nije moguće rezervisati salu " + per1.naziv + " za navedeni datum " + dat + " i termin od " + per1.pocetak + " do " + per1.kraj +
                                    "! U ovom terminu salu je već rezervisao " + o.uloga + " " + o.ime + " " + o.prezime + ".");
                            })
                        })
                    })
                }
            });
        })
    }
})

app.listen(8080);

module.exports = app;