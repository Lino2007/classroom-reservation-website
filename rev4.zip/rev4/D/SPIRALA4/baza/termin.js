const Sequelize = require("sequelize");

module.exports = function (sequelize, DataTypes) {
    const Termin = sequelize.define("termin", {
        redovni: { allowNull: false, type: Sequelize.BOOLEAN },
        dan: { allowNull: true, type: Sequelize.INTEGER },
        datum: { allowNull: true, type: Sequelize.STRING },
        semestar: { allowNull: true, type: Sequelize.STRING },
        pocetak: { allowNull: false, type: Sequelize.TIME },
        kraj: { allowNull: false, type: Sequelize.TIME }
    })
    return Termin;
};

