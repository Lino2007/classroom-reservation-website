const Sequelize = require("sequelize");

module.exports = function (sequelize, DataTypes) {
    const Osoblje = sequelize.define("osoblje", {
        ime: { allowNull: false, type: Sequelize.STRING },
        prezime: { allowNull: false, type: Sequelize.STRING },
        uloga: { allowNull: false, type: Sequelize.STRING }
    })
    return Osoblje;
};
