const Sequelize = require("sequelize");

module.exports = function (sequelize, DataTypes) {
    const Rezervacija = sequelize.define("rezervacija", {
        termin: { allowNull: false, unique: true, type: Sequelize.INTEGER },
        sala: { allowNull: false, type: Sequelize.INTEGER },
        osoba: { allowNull: false, type: Sequelize.INTEGER }
    })
    return Rezervacija;
};
