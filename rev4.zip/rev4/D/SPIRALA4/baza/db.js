const Sequelize = require("sequelize");
const sequelize = new Sequelize("dbwt19", "root", "root", { host: "localhost", dialect: "mysql", logging: false });
const db = {};

db.Sequelize = Sequelize;
db.sequelize = sequelize;


//Import modela
db.osoblje = sequelize.import(__dirname + '/osoblje.js');
db.sala = sequelize.import(__dirname + '/sala.js');
db.termin = sequelize.import(__dirname + '/termin.js');
db.rezervacija = sequelize.import(__dirname + '/rezervacija.js');

//Relacije
//1. Osoblje - jedan na vise - Rezervacija
db.osoblje.hasMany(db.rezervacija, { foreignKey: 'osoba', as: 'rezervacijeOsoba' });

//2. Rezervacija - jedan ja jedan - Termin
db.termin.hasOne(db.rezervacija, { foreignKey: 'termin', as: 'rezervacijaTermin' });

//3. Rezervacija - vise na jedan - Sala
db.sala.hasMany(db.rezervacija, { foreignKey: 'sala' });

db.rezervacija.belongsTo(db.osoblje, { foreignKey: 'osoba', as: 'osobaRezervacija' });
db.rezervacija.belongsTo(db.termin, { foreignKey: 'termin', as: 'terminRezervacija' });
db.rezervacija.belongsTo(db.sala, { foreignKey: 'sala', as: 'salaRezervacija' });
db.sala.belongsTo(db.osoblje, { foreignKey: 'zaduzenaOsoba', as: 'zadOsoba' });

//4. Sala - jedan na jedan - Osoblje
db.osoblje.hasOne(db.sala, { foreignKey: 'zaduzenaOsoba' });

module.exports = db;