const Sequelize = require("sequelize");

module.exports = function (sequelize, DataTypes) {
    const Sala = sequelize.define("sala", {
        naziv: { allowNull: false, type: Sequelize.STRING },
        zaduzenaOsoba: { allowNull: false, type: Sequelize.INTEGER }
    })
    return Sala;
};
