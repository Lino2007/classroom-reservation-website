const db = require('./baza/db.js')
//Inicijalizacija baze
db.sequelize.sync({ force: true }).then(function () {
    inicijalizacija().then(function () {
        console.log("Gotovo kreiranje tabela i ubacivanje pocetnih podataka!");
        process.exit();
    });
});

function inicijalizacija() {
    let osobljeListaPromisea = [];
    let saleListaPromisea = [];
    let terminiListaPromisea = [];
    let rezervacijeListaPromisea = [];
    return new Promise(function (resolve, reject) {
        osobljeListaPromisea.push(db.osoblje.create({ ime: 'Neko', prezime: 'Nekić', uloga: 'profesor' }));
        osobljeListaPromisea.push(db.osoblje.create({ ime: 'Drugi', prezime: 'Neko', uloga: 'asistent' }));
        osobljeListaPromisea.push(db.osoblje.create({ ime: 'Test', prezime: 'Test', uloga: 'asistent' }));

        Promise.all(osobljeListaPromisea).then(function (osoblje) {
            let neko = osoblje.filter(function (a) { return a.ime === 'Neko' && a.prezime === 'Nekić' && a.uloga === 'profesor' })[0];
            let drugi = osoblje.filter(function (a) { return a.ime === 'Drugi' && a.prezime === 'Neko' && a.uloga === 'asistent' })[0];
            let test = osoblje.filter(function (a) { return a.ime === 'Test' && a.prezime === 'Test' && a.uloga === 'asistent' })[0];

            //Ovo promijenjeno - nakon sto je kreirana prva sala - 1-11, onda kreiraj drugu salu - 1-15
            saleListaPromisea.push(db.sala.create({ naziv: '1-11', zaduzenaOsoba: neko.id }).then(function (s) {
                saleListaPromisea.push(db.sala.create({ naziv: '1-15', zaduzenaOsoba: drugi.id }));
                return new Promise(function (resolve, reject) { resolve(s); });
            }));

            Promise.all(saleListaPromisea).then(function (sale) {
                let sala1_11 = sale.filter(function (a) { return a.naziv === '1-11' && a.zaduzenaOsoba === 1 })[0];
                let sala1_15 = sale.filter(function (a) { return a.naziv === '1-15' && a.zaduzenaOsoba === 2 })[0];

                terminiListaPromisea.push(db.termin.create({ redovni: false, dan: null, datum: '01.01.2020', semestar: null, pocetak: '12:00', kraj: '13:00' }));
                terminiListaPromisea.push(db.termin.create({ redovni: true, dan: 0, datum: null, semestar: 'zimski', pocetak: '13:00', kraj: '14:00' }));

                Promise.all(terminiListaPromisea).then(function (termini) {
                    let termin1 = termini.filter(function (a) { return a.redovni === false && a.dan === null && a.datum === '01.01.2020' && a.semestar === null && a.pocetak === '12:00' && a.kraj === '13:00' })[0];
                    let termin2 = termini.filter(function (a) { return a.redovni === true && a.dan === 0 && a.datum === null && a.semestar === 'zimski' && a.pocetak === '13:00' && a.kraj === '14:00' })[0];

                    rezervacijeListaPromisea.push(db.rezervacija.create({ termin: termin1.id, sala: sala1_11.id, osoba: neko.id }));
                    rezervacijeListaPromisea.push(db.rezervacija.create({ termin: termin2.id, sala: sala1_11.id, osoba: test.id }));

                    Promise.all(rezervacijeListaPromisea).then(function (b) { resolve(b); }).catch(function (err) { console.log("Rezervacije greska " + err); });
                }).catch(function (err) { console.log("Termini greska (pri inicijalizaciji): " + err); });
            }).catch(function (err) { console.log("Sale greska (pri inicijalizaciji): " + err); });
        }).catch(function (err) { console.log("Osoblje greska (pri inicijalizaciji): " + err); });
    })
}
