const supertest = require("supertest");
const assert = require('assert');
const app = require("./index");

/*!!!NAPOMENA!!!: Prilikom pokretanja testova, potrebno je:
        1. Pokrenuti index.js iz terminala: node index.js
        2. Zakomentarisati u index.js linije 227-231
        3. Pokrenuti testove iz terminala: npm test
*/

describe("GET /osoblje", function () {
    it("Status code mora biti 200", function (done) {
        supertest(app)
            .get("/osoblje")
            .expect(200)
            .end(function (err, res) {
                if (err) done(err);
                done();
            });
    });

    it("Provjera da li su vraceni svi podaci iz tabele osoblje", function (done) {
        supertest(app)
            .get("/osoblje")
            .expect([
                { "id": 1, "ime": "Neko", "prezime": "Nekić", "uloga": "profesor" },
                { "id": 2, "ime": "Drugi", "prezime": "Neko", "uloga": "asistent" },
                { "id": 3, "ime": "Test", "prezime": "Test", "uloga": "asistent" }
            ])
            .end(function (err, res) {
                if (err) done(err);
                done();
            });
    });
});

describe("GET /sale", function () {
    it("Status code mora biti 200", function (done) {
        supertest(app)
            .get("/sale")
            .expect(200)
            .end(function (err, res) {
                if (err) done(err);
                done();
            });
    });

    it("Provjera da li su vraceni svi podaci iz tabele sala", function (done) {
        supertest(app)
            .get("/sale")
            .expect([
                { "id": 1, "naziv": "1-11", "zaduzenaOsoba": 1 },
                { "id": 2, "naziv": "1-15", "zaduzenaOsoba": 2 }
            ])
            .end(function (err, res) {
                if (err) done(err);
                done();
            });
    });
});

describe("GET /zauzeca", function () {
    it("Status code mora biti 200", function (done) {
        supertest(app)
            .get("/zauzeca")
            .expect(200)
            .end(function (err, res) {
                if (err) done(err);
                done();
            });
    });

    it("Provjera da li je adekvatno vracena lista osoblja pored kojih pise u kojoj sali su trenutno (sa inicijalnim podacima u bazi)", function (done) {
        supertest(app)
            .get("/zauzeca")
            .expect([
                { "imeOsobe": "Neko Nekić", "osobaSala": "u kancelariji" },
                { "imeOsobe": "Drugi Neko", "osobaSala": "u kancelariji" },
                { "imeOsobe": "Test Test", "osobaSala": "u kancelariji" }])
            .end(function (err, res) {
                if (err) done(err);
                done();
            });
    });
});


describe("GET /ucitajIzBaze", function () {
    it("Status code mora biti 200", function (done) {
        supertest(app)
            .get("/ucitajIzBaze")
            .expect(200)
            .end(function (err, res) {
                if (err) done(err);
                done();
            });
    });

    it("Provjera da li su vraceni svi podaci iz baze (sa inicijalnim podacima u bazi)", function (done) {
        supertest(app)
            .get("/ucitajIzBaze")
            .expect({
                "periodicna": [
                    { "dan": "0", "semestar": "zimski", "pocetak": "13:00", "kraj": "14:00", "naziv": "1-11", "predavac": "Test Test" }
                ],
                "vanredna": [
                    { "datum": "01.01.2020", "pocetak": "12:00", "kraj": "13:00", "naziv": "1-11", "predavac": "Neko Nekić" }
                ]
            })
            .end(function (err, res) {
                if (err) done(err);
                done();
            });
    });
});

describe("POST /upisiVanrednoZauzeceUBazu", function () {
    it("Provjera upisa novog vanrednog zauzeca u bazu", function (done) {
        supertest(app)
            .post("/upisiVanrednoZauzeceUBazu")
            .send({
                "vanrednoZauzece": { "datum": "28.01.2020", "pocetak": "09:00", "kraj": "12:00", "naziv": "1-15", "predavac": "Neko Nekić" },
                "zauzeca": {
                    "periodicna": [
                        { "dan": "0", "semestar": "zimski", "pocetak": "13:00", "kraj": "14:00", "naziv": "1-11", "predavac": "Test Test" }
                    ],
                    "vanredna": [
                        { "datum": "01.01.2020", "pocetak": "12:00", "kraj": "13:00", "naziv": "1-11", "predavac": "Neko Nekić" }
                    ]
                }
            })
            .expect(200)
            .end(function (err, res) {
                if (err) done(err);
                done();
            });
    });
});

describe("GET /ucitajIzBaze", function () {
    it("Provjera da li su vraceni svi podaci iz baze (sa novododanim vanrednim zauzecem)", function (done) {
        supertest(app)
            .get("/ucitajIzBaze")
            .expect({
                "periodicna": [
                    { "dan": "0", "semestar": "zimski", "pocetak": "13:00", "kraj": "14:00", "naziv": "1-11", "predavac": "Test Test" }
                ],
                "vanredna": [
                    { "datum": "01.01.2020", "pocetak": "12:00", "kraj": "13:00", "naziv": "1-11", "predavac": "Neko Nekić" },
                    { "datum": "28.01.2020", "pocetak": "09:00", "kraj": "12:00", "naziv": "1-15", "predavac": "Neko Nekić" }
                ]
            })
            .end(function (err, res) {
                if (err) done(err);
                done();
            });
    });
});

describe("POST /upisiPeriodicnoZauzeceUBazu", function () {
    it("Provjera upisa novog periodicnog zauzeca u bazu", function (done) {
        supertest(app)
            .post("/upisiPeriodicnoZauzeceUBazu")
            .send({
                "periodicnoZauzece": {
                    "dan": "2",
                    "semestar": "ljetni",
                    "pocetak": "12:00",
                    "kraj": "15:00",
                    "naziv": "1-11",
                    "predavac": "Neko Nekić"
                },
                "zauzeca": {
                    "periodicna": [
                        { "dan": "0", "semestar": "zimski", "pocetak": "13:00", "kraj": "14:00", "naziv": "1-11", "predavac": "Test Test" }
                    ],
                    "vanredna": [
                        { "datum": "01.01.2020", "pocetak": "12:00", "kraj": "13:00", "naziv": "1-11", "predavac": "Neko Nekić" },
                        { "datum": "28.01.2020", "pocetak": "09:00", "kraj": "12:00", "naziv": "1-15", "predavac": "Neko Nekić" }
                    ]
                },
                "datum": "07.04.2020"
            })
            .expect(200)
            .end(function (err, res) {
                if (err) done(err);
                done();
            });
    });
});



describe("GET /ucitajIzBaze", function () {
    it("Provjera da li su vraceni svi podaci iz baze (sa novododanim periodicnim zauzecem)", function (done) {
        supertest(app)
            .get("/ucitajIzBaze")
            .expect({
                "periodicna": [
                    { "dan": "0", "semestar": "zimski", "pocetak": "13:00", "kraj": "14:00", "naziv": "1-11", "predavac": "Test Test" },
                    { "dan": "2", "semestar": "ljetni", "pocetak": "12:00", "kraj": "15:00", "naziv": "1-11", "predavac": "Neko Nekić" }
                ],
                "vanredna": [
                    { "datum": "01.01.2020", "pocetak": "12:00", "kraj": "13:00", "naziv": "1-11", "predavac": "Neko Nekić" },
                    { "datum": "28.01.2020", "pocetak": "09:00", "kraj": "12:00", "naziv": "1-15", "predavac": "Neko Nekić" }
                ]
            })
            .end(function (err, res) {
                if (err) done(err);
                done();
            });
    });
});


//Preklapanje periodicno - vanredno
describe("POST /upisiPeriodicnoZauzeceUBazu", function () {
    it("Provjera upisa novog periodicnog zauzeca u bazu ukoliko se termin preklapa sa jednim vanrednim zauzecem", function (done) {
        supertest(app)
            .post("/upisiPeriodicnoZauzeceUBazu")
            .send({
                "periodicnoZauzece": {
                    "dan": "2",
                    "semestar": "zimski",
                    "pocetak": "09:00",
                    "kraj": "14:00",
                    "naziv": "1-15",
                    "predavac": "Test Test"
                },
                "zauzeca": {
                    "periodicna": [
                        { "dan": "0", "semestar": "zimski", "pocetak": "13:00", "kraj": "14:00", "naziv": "1-11", "predavac": "Test Test" },
                        { "dan": "2", "semestar": "ljetni", "pocetak": "12:00", "kraj": "15:00", "naziv": "1-11", "predavac": "Neko Nekić" }
                    ],
                    "vanredna": [
                        { "datum": "01.01.2020", "pocetak": "12:00", "kraj": "13:00", "naziv": "1-11", "predavac": "Neko Nekić" },
                        { "datum": "28.01.2020", "pocetak": "09:00", "kraj": "12:00", "naziv": "1-15", "predavac": "Neko Nekić" }
                    ]
                },
                "datum": "14.01.2020"
            })
            .expect(200)
            .end(function (err, res) {
                if (err) done(err);
                done();
            });
    });
});



describe("GET /ucitajIzBaze", function () {
    it("Provjera da li su vraceni svi podaci iz baze (bez periodicnog zauzeca koje ima preklapanje)", function (done) {
        supertest(app)
            .get("/ucitajIzBaze")
            .expect({
                "periodicna": [
                    { "dan": "0", "semestar": "zimski", "pocetak": "13:00", "kraj": "14:00", "naziv": "1-11", "predavac": "Test Test" },
                    { "dan": "2", "semestar": "ljetni", "pocetak": "12:00", "kraj": "15:00", "naziv": "1-11", "predavac": "Neko Nekić" }
                ],
                "vanredna": [
                    { "datum": "01.01.2020", "pocetak": "12:00", "kraj": "13:00", "naziv": "1-11", "predavac": "Neko Nekić" },
                    { "datum": "28.01.2020", "pocetak": "09:00", "kraj": "12:00", "naziv": "1-15", "predavac": "Neko Nekić" }
                ]
            })
            .end(function (err, res) {
                if (err) done(err);
                done();
            });
    });
});

/*
//Preklapanje vanredno - periodicno
describe("POST /upisiVanrednoZauzeceUBazu", function () {
    it("Provjera upisa novog vanrednog zauzeca u bazu ukoliko se termin preklapa sa jednim periodicnim zauzecem", function (done) {
        supertest(app)
            .post("/upisiVanrednoZauzeceUBazu")
            .send({
                "vanrednoZauzece": { "datum": "15.11.2020", "pocetak": "09:00", "kraj": "14:00", "naziv": "1-11", "predavac": "Neko Nekić" },
                "zauzeca": {
                    "periodicna": [
                        { "dan": "2", "semestar": "ljetni", "pocetak": "12:00", "kraj": "15:00", "naziv": "1-11", "predavac": "Neko Nekić" },
                        { "dan": "0", "semestar": "zimski", "pocetak": "13:00", "kraj": "14:00", "naziv": "1-11", "predavac": "Test Test" }
                    ],
                    "vanredna": [
                        { "datum": "28.01.2020", "pocetak": "09:00", "kraj": "12:00", "naziv": "1-15", "predavac": "Neko Nekić" },
                        { "datum": "01.01.2020", "pocetak": "12:00", "kraj": "13:00", "naziv": "1-11", "predavac": "Neko Nekić" },
                    ]
                }
            })
            .expect(200)
            .end(function (err, res) {
                if (err) done(err);
                done();
            });
    });
});

describe("GET /ucitajIzBaze", function () {
    it("Provjera da li su vraceni svi podaci iz baze (bez vanrednog zauzeca koje ima preklapanje)", function (done) {
        supertest(app)
            .get("/ucitajIzBaze")
            .expect({
                "periodicna": [
                    { "dan": "0", "semestar": "zimski", "pocetak": "13:00", "kraj": "14:00", "naziv": "1-11", "predavac": "Test Test" },
                    { "dan": "2", "semestar": "ljetni", "pocetak": "12:00", "kraj": "15:00", "naziv": "1-11", "predavac": "Neko Nekić" }
                ],
                "vanredna": [
                    { "datum": "01.01.2020", "pocetak": "12:00", "kraj": "13:00", "naziv": "1-11", "predavac": "Neko Nekić" },
                    { "datum": "28.01.2020", "pocetak": "09:00", "kraj": "12:00", "naziv": "1-15", "predavac": "Neko Nekić" }
                ]
            })
            .end(function (err, res) {
                if (err) done(err);
                done();
            });
    });
});
*/