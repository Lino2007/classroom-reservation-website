window.onload = function () {
    Kalendar.iscrtajKalendar(Kalendar.dajKalendar(), Kalendar.dajTrenutniMjesec());
    Pozivi.ucitajPodatkeIzBaze();   //ucitavanje podataka iz baze
    Pozivi.ucitajOsoblje(); //popunjavanje select polja (za osoblje) sa podacima iz baze
    Pozivi.ucitajSale(); //popunjavanje select polja (za sale) sa podacima iz baze
};

var kliknutiDatum = "";
var kliknutoZauzece = "";

function postaviOdabraniDan(tabelaDan) {
    kliknutiDatum = tabelaDan.getElementsByTagName("td")[0].innerHTML;
    kliknutoZauzece = tabelaDan.getElementsByTagName("td")[1];
}

function odabranDan(tabelaDan) {
    postaviOdabraniDan(tabelaDan);
    let sala = document.getElementById("sala").value;
    let pocetak = document.getElementById("pocetak").value;
    let kraj = document.getElementById("kraj").value;

    //ako sva polja nisu oznacena ne radi nista
    if (sala === "" || pocetak === "" || kraj === "" || USekunde(pocetak) > USekunde(kraj)) return;

    otvoriConfirm("Da li želite rezervisati ovaj termin?", "confirm/Calendar_Alert_Icon.png", "DA", "NE");
}

function otvoriConfirm(tekst, slika_src, btnDa, btnNe) {
    let confirm = document.getElementsByClassName("confirm")[0];
    let confirm_text = document.getElementsByClassName("confirm_text")[0];
    let confirm_alert_icon = document.getElementsByClassName("alert_icon")[0];
    let confirm_button_da = document.getElementsByClassName("confirm_button_da")[0];
    let confirm_button_ne = document.getElementsByClassName("confirm_button_ne")[0];

    confirm_alert_icon.src = slika_src;
    confirm_text.innerHTML = tekst;
    if (btnDa != "") {
        confirm_button_da.innerHTML = btnDa;
        confirm_button_da.style.display = "block";
    }
    else confirm_button_da.style.display = "none";
    if (btnNe != "") {
        confirm_button_ne.innerHTML = btnNe;
        confirm_button_ne.style.display = "block";
    }
    else confirm_button_ne.style.display = "none";

    confirm.style.display = "flex";
}

function zatvoriConfirm() {
    let confirm = document.getElementsByClassName("confirm")[0];
    confirm.style.display = "none";
}


function klinutoDa() {
    if (kliknutiDatum < 10 && kliknutiDatum.length === 1) kliknutiDatum = "0" + kliknutiDatum;
    let mj = dajIndeks(document.getElementsByClassName("kalendar")[0].caption.innerHTML) + 1;
    let mjesec = mj.toString();
    if (mjesec < 10 && mjesec.length === 1) mjesec = "0" + mjesec;

    let sala = document.getElementById("sala").value;
    let periodicna = document.getElementById("periodicna").checked;
    let pocetak = document.getElementById("pocetak").value;
    let kraj = document.getElementById("kraj").value;
    let predavac = document.getElementById("osoblje").value;

    var trenutniDatum = new Date();
    var trenutnaGodina = trenutniDatum.getFullYear();

    //ako je zauzece vanredno
    if (!periodicna) {
        let datum = kliknutiDatum + "." + mjesec + "." + trenutnaGodina;
        Pozivi.upisiVanrednoZauzeceUBazu(datum, pocetak, kraj, sala, predavac); //Upisivanje vanrednog zauzeca u bazu
    }
    //ako je zauzece periodicno
    else {
        let datum = kliknutiDatum + "." + mjesec + "." + trenutnaGodina;
        let dan = new Date(trenutnaGodina + "-" + mjesec + "-" + kliknutiDatum).getDay();
        let semestar = "";
        if (mjesec === "01" || mjesec === "10" || mjesec == "11" || mjesec == "12") semestar = "zimski";
        else if (mjesec === "02" || mjesec === "03" || mjesec === "04" || mjesec === "05" || mjesec === "06") semestar = "ljetni";
        Pozivi.upisiPeriodicnoZauzeceUBazu(dan, semestar, pocetak, kraj, sala, predavac, datum); //Upisivanje periodicnog zauzeca u bazu
    }
}
