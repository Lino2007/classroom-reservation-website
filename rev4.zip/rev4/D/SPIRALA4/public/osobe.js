function osvjeziPodatkeOsoblje() {
    Pozivi.vratiZauzeca();
}

window.onload = function () {
    osvjeziPodatkeOsoblje();
    ProgressCountdown(30, 'pageBeginCountdown', 'pageBeginCountdownText');
};

setInterval(function () {
    osvjeziPodatkeOsoblje()
}, 30000);


function ProgressCountdown(timeleft, bar, text) {
    return new Promise((resolve, reject) => {
        setInterval(() => {
            timeleft--;
            document.getElementById(bar).value = timeleft;
            document.getElementById(text).textContent = timeleft;
            if (timeleft <= 0) {
                timeleft = 30;
                resolve(true);
            }
        }, 1000);
    });
}