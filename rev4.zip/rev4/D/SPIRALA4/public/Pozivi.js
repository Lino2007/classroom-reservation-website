let Pozivi = (function () {

    function ucitajSlikeImpl() {
        var ajax = new XMLHttpRequest();
        ajax.onreadystatechange = function () {
            if (ajax.readyState == 4) {
                let slike = JSON.parse(ajax.responseText);
                if (slike.length != 0) {
                    if (slike.length < 3) {
                        postaviUcitaneSveSlike(true);
                        document.getElementById("sljedeci").disabled = true;
                        if (ucitaneSlike.length <= 3) document.getElementById("prethodni").disabled = true;
                    }
                    else postaviUcitaneSveSlike(false);
                    //prve tri slike
                    if (ucitaneSlike.length === 0) {
                        for (let i = 0; i < slike.length; i++) {
                            let s = new Image();
                            s.id = "slika" + slike[i].id;
                            s.alt = "slika" + slike[i].id;
                            s.src = slike[i].src;
                            s.classList.add("galerija");
                            document.getElementById("s" + i.toString()).appendChild(s);
                        }
                        UpisiUcitaneSlike(slike);
                    }
                    else {
                        for (let i = 0; i < slike.length; i++) {
                            let s = document.getElementById("s" + i.toString()).getElementsByTagName("img")[0];
                            s.id = "slika" + slike[i].id;
                            s.alt = "slika" + slike[i].id;
                            s.src = slike[i].src;
                        }
                        for (let i = slike.length; i < 3; i++) {
                            document.getElementById("s" + i.toString()).getElementsByTagName("img")[0].style.display = "none";
                        }
                        UpisiUcitaneSlike(slike);
                    }
                }
                else {
                    postaviUcitaneSveSlike(true);
                    if (ucitaneSlike.length % 3 === 0) {
                        document.getElementById("sljedeci").disabled = true;
                        if (ucitanesveSlike && ucitaneSlike.length != 0 && document.getElementById("s0").getElementsByTagName("img")[0].id === "slika1")
                            document.getElementById("prethodni").disabled = true;
                    }
                }
            }

            if (ajax.readyState == 4 && ajax.status == 404)
                console.log("ERROR: 404");
        }
        ajax.open("GET", 'slike', true);
        ajax.send();
    }

    function oznaciNeucitaneImpl() {
        var ajax = new XMLHttpRequest();
        ajax.onreadystatechange = function () {
            if (ajax.readyState == 4) {
            }
            if (ajax.readyState == 4 && ajax.status == 404)
                console.log("ERROR: 404");
        }
        ajax.open("GET", '/oznaciSlike', true);
        ajax.send();
    }

    //SPIRALA 4.
    //Zadatak 1.
    function ucitajOsobljeImpl() {
        var ajax = new XMLHttpRequest();
        ajax.onreadystatechange = function () {
            if (ajax.readyState == 4) {
                let rezultat = JSON.parse(ajax.responseText);
                let selectOsoblje = document.getElementById("osoblje");
                rezultat.forEach(e => {
                    let option = document.createElement("option");
                    option.text = e.ime.toString() + " " + e.prezime.toString();
                    option.value = e.ime.toString() + " " + e.prezime.toString();
                    selectOsoblje.add(option);
                });
                console.log("Ucitani podaci u select polje za odabir osoblja!");
            }
            if (ajax.readyState == 4 && ajax.status == 404)
                console.log("ERROR: 404");
        }
        ajax.open("GET", 'osoblje', true);
        ajax.send();
    }

    function ucitajSaleImpl() {
        var ajax = new XMLHttpRequest();
        ajax.onreadystatechange = function () {
            if (ajax.readyState == 4) {
                let rezultat = JSON.parse(ajax.responseText);
                let selectSale = document.getElementById("sala");
                rezultat.forEach(e => {
                    let option = document.createElement("option");
                    option.text = e.naziv.toString();
                    option.value = e.naziv.toString();
                    selectSale.add(option);
                });
                console.log("Ucitani podaci u select polje za odabir sale!");
            }
            if (ajax.readyState == 4 && ajax.status == 404)
                console.log("ERROR: 404");
        }
        ajax.open("GET", 'sale', true);
        ajax.send();
    }

    //Zadatak 3.
    function vratiZauzecaImpl() {
        var ajax = new XMLHttpRequest();
        ajax.onreadystatechange = function () {
            if (ajax.readyState == 4) {
                let rezultat = JSON.parse(ajax.responseText);

                //Brisemo postojece redove
                let br = document.getElementsByTagName("tr").length;
                for (let i = br - 1; i > 0; i--) {
                    document.getElementsByClassName("osobeSale")[0].deleteRow(i);
                    br--;
                }
                //Dodajemo nove redove
                for (let i = 0; i < rezultat.length; i++) {
                    let red = document.getElementsByClassName("osobeSale")[0].insertRow(i + 1);
                    red.setAttribute("class", "red");
                    let osoba = red.insertCell(0);
                    let sala = red.insertCell(1);
                    osoba.innerHTML = rezultat[i].imeOsobe;
                    sala.innerHTML = rezultat[i].osobaSala;
                }
                console.log("Azuriranje prikaza liste osoblja!");

            }
            if (ajax.readyState == 4 && ajax.status == 404)
                console.log("ERROR: 404");
        }
        ajax.open("GET", 'zauzeca', true);
        ajax.send();
    }

    //Zadatak 2.
    function ucitajPodatkeIzBazeImpl() {
        var ajax = new XMLHttpRequest();
        ajax.onreadystatechange = function () {
            if (ajax.readyState == 4) {
                var zauzeca = JSON.parse(ajax.responseText);
                Kalendar.ucitajPodatke(zauzeca.periodicna, zauzeca.vanredna);
                console.log("Ucitani podaci iz baze!")
            }
            if (ajax.readyState == 4 && ajax.status == 404)
                console.log("ERROR: 404");
        }
        ajax.open("GET", "ucitajIzBaze", true);
        ajax.send();
    }

    //Ova metoda dobavlja sva zauzeca, a potom poziva metodu koja upisuje vanredno zauzece, ili vraca poruku da je doslo do greske
    function upisiVanrednoZauzeceUBazuImpl(datum, pocetak, kraj, naziv, predavac) {
        var ajax = new XMLHttpRequest();
        ajax.onreadystatechange = function () {
            if (ajax.readyState == 4) {
                var zauzeca = JSON.parse(ajax.responseText);
                var vanrednoZauzece = { datum: datum, pocetak: pocetak, kraj: kraj, naziv: naziv, predavac: predavac };
                upisiVanrednoUBazuImpl({ vanrednoZauzece, zauzeca });
            }
            if (ajax.readyState == 4 && ajax.status == 404)
                console.log("ERROR: 404");
        }
        ajax.open("GET", "ucitajIzBaze", true);
        ajax.send();
    }

    //Ova metoda vrsi upisivanje vanrednog zauzeca, ili vraca poruku da je doslo do greske
    function upisiVanrednoUBazuImpl(obj) {
        var ajax = new XMLHttpRequest();
        ajax.onreadystatechange = function () {
            if (ajax.readyState == 4) {
                var contentType = ajax.getResponseHeader("Content-Type");
                if (contentType === "text/plain; charset=utf-8") {
                    var tekst = ajax.responseText;
                    zatvoriConfirm();
                    otvoriConfirm(tekst, "confirm/error.png", "", "OK");
                }
                else if (contentType === "application/json; charset=utf-8") {
                    var zauzeca = JSON.parse(ajax.responseText);
                    Kalendar.ucitajPodatke(zauzeca.periodicna, zauzeca.vanredna);
                    Kalendar.SalaOboji();
                    zatvoriConfirm();
                    otvoriConfirm("Uspješno rezervisan termin!", "confirm/success.png", "", "OK");
                }
            }
            if (ajax.readyState == 4 && ajax.status == 404)
                console.log("ERROR: 404");
        }
        ajax.open("POST", "upisiVanrednoZauzeceUBazu", true);
        ajax.setRequestHeader("Content-type", "application/json");
        ajax.send(JSON.stringify(obj));
    }

    //Ova metoda dobavlja sva zauzeca, a potom poziva metodu koja upisuje periodicno zauzece, ili vraca poruku da je doslo do greske
    function upisiPeriodicnoZauzeceUBazuImpl(dan, semestar, pocetak, kraj, naziv, predavac, datum) {
        var ajax = new XMLHttpRequest();
        ajax.onreadystatechange = function () {
            if (ajax.readyState == 4) {
                var zauzeca = JSON.parse(ajax.responseText);
                var periodicnoZauzece = { dan: dan, semestar: semestar, pocetak: pocetak, kraj: kraj, naziv: naziv, predavac: predavac };
                console.log(periodicnoZauzece);
                upisiPeriodicnoUBazuImpl({ periodicnoZauzece, zauzeca, datum });
            }
            if (ajax.readyState == 4 && ajax.status == 404)
                console.log("ERROR: 404");
        }
        ajax.open("GET", "ucitajIzBaze", true);
        ajax.send();
    }

    //Ova metoda vrsi upisivanje periodicnog zauzeca, ili vraca poruku da je doslo do greske
    function upisiPeriodicnoUBazuImpl(obj) {
        var ajax = new XMLHttpRequest();
        ajax.onreadystatechange = function () {
            if (ajax.readyState == 4) {
                var contentType = ajax.getResponseHeader("Content-Type");
                if (contentType === "text/plain; charset=utf-8") {
                    var tekst = ajax.responseText;
                    zatvoriConfirm();
                    otvoriConfirm(tekst, "confirm/error.png", "", "OK");
                }
                else if (contentType === "application/json; charset=utf-8") {
                    var zauzeca = JSON.parse(ajax.responseText);
                    Kalendar.ucitajPodatke(zauzeca.periodicna, zauzeca.vanredna);
                    Kalendar.SalaOboji();
                    zatvoriConfirm();
                    otvoriConfirm("Uspješno rezervisan termin!", "confirm/success.png", "", "OK");
                }
            }
            if (ajax.readyState == 4 && ajax.status == 404)
                console.log("ERROR: 404");
        }
        ajax.open("POST", "upisiPeriodicnoZauzeceUBazu", true);
        ajax.setRequestHeader("Content-type", "application/json");
        ajax.send(JSON.stringify(obj));
    }

    return {
        ucitajSlike: ucitajSlikeImpl,
        oznaciNeucitane: oznaciNeucitaneImpl,
        ucitajOsoblje: ucitajOsobljeImpl,
        ucitajSale: ucitajSaleImpl,
        vratiZauzeca: vratiZauzecaImpl,
        ucitajPodatkeIzBaze: ucitajPodatkeIzBazeImpl,
        upisiVanrednoZauzeceUBazu: upisiVanrednoZauzeceUBazuImpl,
        upisiVanrednoUBazu: upisiVanrednoUBazuImpl,
        upisiPeriodicnoZauzeceUBazu: upisiPeriodicnoZauzeceUBazuImpl,
        upisiPeriodicnoUBazu: upisiPeriodicnoUBazuImpl
    };
})();

